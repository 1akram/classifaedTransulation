<?php
/*
 * Add action to display the Tevolution-Classifieds plugin in extend tab on Tevolution dashboard.
 */
add_action( 'templconnector_bundle_box','add_tevolution_classifieds_bundle_box' );
function add_tevolution_classifieds_bundle_box() {
	$activated = @$_REQUEST['activated'];
	$deactivate = @$_REQUEST['deactivate'];
	if ( function_exists( 'templatic_module_activationmsg' ) ) {
		if ( $activated ) {
			templatic_module_activationmsg( 'tevolution_classifieds','Tevolution Classifieds','',$mod_message = '',$realted_mod = '' );
		} else { 			templatic_module_activationmsg( 'tevolution_classifieds','Tevolution Classifieds','',$mod_message = '',$realted_mod = '' );
		}
	}
?>
	<div id="templatic_tevolution_classified" class="widget_div">
		<div title="Click to toggle" class="handlediv"></div>
			<h3 class="hndle"><span><?php _e( 'Tevolution Classifieds','classifieds' ); ?></span></h3>
		<div class="inside">
			  <img class="dashboard_img" src="<?php echo TEVOLUTION_CLASSIFIEDS_URL?>images/icon-property-manager.png" />
			<?php
			_e( 'An classifieds module that will let you add, sort and manage your properties easily and effectively. By management, we mean you can do excerpt settings, decide the publishing status on property addition, fire e-mail notification to user on event expiry, sort the listings as per the locations and their near by locations too. Show and share your listings using your social accounts from your website itself and many more.','classifieds' );
			?>
			<div class="clearfixb"></div>          
			<?php if ( ! is_active_addons( 'tevolution_classifieds' ) ) :?>
			<div id="publishing-action">
				<a href="<?php echo site_url() . '/wp-admin/admin.php?page=templatic_system_menu&activated=tevolution_classifieds&true=1';?>" class="templatic-tooltip button-primary"><?php _e( 'Activate &rarr;','classifieds' ); ?></a>
			</div>
			<?php  endif;?>
	<?php  if ( is_active_addons( 'tevolution_classifieds' ) ) : ?>
			<div class="settings_style">
			<a href="<?php echo site_url() . '/wp-admin/admin.php?page=templatic_system_menu&deactivate=tevolution_classifieds&true=0';?>" class="deactive_lnk"><?php _e( 'Deactivate ','classifieds' ); ?></a>|
			<a class="templatic-tooltip set_lnk" href="<?php echo site_url() . '/wp-admin/admin.php?page=directory_settings';?>"><?php _e( 'Settings','classifieds' ); ?></a>            
			</div>
	<?php endif; ?>
		</div>
	</div>
<?php
}
?>
