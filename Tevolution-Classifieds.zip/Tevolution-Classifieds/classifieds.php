<?php
/*
Plugin Name: Tevolution - Classifieds
Plugin URI: //templatic.com/
Description: Tevolution - Classified plugin is specially built to turn your site into a powerful classified site.
Version: 1.2.1
Author: Templatic
Author URI: //templatic.com/
*/
ob_start();
include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
define( 'TEVOLUTION_CLASSIFIEDS_VERSION', '1.2.1' );
define( 'TEVOLUTION_CLASSIFIEDS_SLUG','Tevolution-Classifieds/classifieds.php' );
/* Plug in Folder URL*/
define( 'TEVOLUTION_CLASSIFIEDS_URL', plugin_dir_url( __FILE__ ) );
/* Plug in Folder Path */
define( 'TEVOLUTION_CLASSIFIEDS_DIR', plugin_dir_path( __FILE__ ) );
/* Plug-in Root File */
define( 'TEVOLUTION_CLASSIFIEDS_FILE', __FILE__ );
@define( 'TEVOLUTION_CLASSIFIEDS_URL',plugin_dir_url( __FILE__ ) );


/* Load style sheet on front pages */
add_action( 'init', 'tmpl_classifieds_widget_setup' );

add_image_size( 'adv_detail-main-img',480,480,true );

/* listing page featured thumbnail */
add_image_size( 'adv_listings-thumb',250,165,true );
/* add_image_size('classified_slider_img_thumb',155,122,true); */



/* Add classifieds css above the directory plugin */
add_action( 'tevolution_css', 'tmpl_add_classifieds_front_stylesheet',14 );

function tmpl_add_classifieds_front_stylesheet() {

	if ( function_exists( 'tmpl_wp_is_mobile' ) && ! tmpl_wp_is_mobile() ) {
		global $tev_css;
		if ( ! empty( $tev_css ) ) {
			$tev_css = array_merge( $tev_css,array( TEVOLUTION_CLASSIFIEDS_DIR . 'css/style.css' ) );
		} else {
			$tev_css = array( TEVOLUTION_CLASSIFIEDS_DIR . 'css/style.css' );
		}
	}
}
add_action( 'wp_enqueue_scripts', 'tmpl_basic_stylesheet',19 );

function tmpl_basic_stylesheet() {

	if ( ! tmpl_wp_is_mobile() ) {

		/* if "allow_url_fopen" is enabled then apply minifiled css otherwise includse seperately */
		$tmpl_is_allow_url_fopen = tmpl_is_allow_url_fopen();
		if ( ! $tmpl_is_allow_url_fopen ) {
			wp_enqueue_style( 'tmpl_classified_style', plugins_url( 'css/style.css', __FILE__ ) );
		}

		/*wp_enqueue_style( 'tmpl_classified_style');	*/
		if ( is_single() ) {
			wp_enqueue_style( 'tmpl_classified_print_style', plugins_url( 'css/print.css', __FILE__ ) );
		}
	}

}
/* remove header right widget area */
function tmpl_classifieds_widget_setup() {
	$args = array(
	'name'          => __( 'Footer Right', 'classifieds' ),
	'id'            => 'footer_right',
	'description'   => '',
		'class'         => '',
	'before_widget' => '<div id="%1$s" class="widget %2$s">',
	'after_widget'  => '</div>',
	'before_title'  => '<h2 class="widgettitle">',
	'after_title'   => '</h2>',
	);
	register_sidebar( $args );
}

/* including localization */
add_action( 'init','tmpl_classified_localization' );
function tmpl_classified_localization() {

	/* localization */
	$locale = get_locale();
	load_textdomain( 'classifieds', TEVOLUTION_CLASSIFIEDS_DIR . 'languages/' . $locale . '.mo' );
}
/* plug in set up */
if ( is_plugin_active( 'Tevolution/templatic.php' ) ) {
	/* Include the tevolution plug in main file to use the core functionalities of plug in. */
	if ( is_plugin_active( 'Tevolution/templatic.php' ) && file_exists( WP_PLUGIN_DIR . '/Tevolution/templatic.php' ) ) {
		include_once( WP_PLUGIN_DIR . '/Tevolution/templatic.php' );
	} else {
		if ( function_exists( 'dd_admin_notices' ) ) {
			add_action( 'admin_notices','dd_admin_notices' );
		}
	}
	/* Bundle Box*/
	if ( is_admin() && (isset( $_REQUEST['page'] ) && $_REQUEST['page'] == 'templatic_system_menu') ) {
		include( TEVOLUTION_CLASSIFIEDS_DIR . 'bundle_box.php' );
	}


	/* file to set up custom post type */
	include_once( TEVOLUTION_CLASSIFIEDS_DIR . 'classifieds/classified.php' );

	/* classifieds widget file */
	include_once( TEVOLUTION_CLASSIFIEDS_DIR . 'functions/widgets.php' );

	if ( (is_admin() && strstr( $_SERVER['REQUEST_URI'],'/wp-admin/' )) && ! defined( 'DOING_AJAX' ) ) {

		/* classifieds filters for search & sorting  */

		include_once( TEVOLUTION_CLASSIFIEDS_DIR . 'functions/admin_functions.php' );
	} else {

		/* file to set up custom templates and functions */

		include_once( TEVOLUTION_CLASSIFIEDS_DIR . 'functions/classifieds_functions.php' );

		/* file to set up custom templates and functions */

		include_once( TEVOLUTION_CLASSIFIEDS_DIR . 'functions/classifieds_templates.php' );

		/* classifieds filters for search & sorting  */
		include_once( TEVOLUTION_CLASSIFIEDS_DIR . 'functions/classifieds_filters.php' );

		/* classifieds filters for search & sorting  */
		include_once( TEVOLUTION_CLASSIFIEDS_DIR . 'functions/classifieds_filters_functions.php' );

	}

	/* renew product code starts here */
	if ( is_admin() ) {
		$tmpl_renew_product = get_option( 'tmpl_renew_product' );

		$tmpl_renew_product_array = explode( ',',$tmpl_renew_product );
		foreach ( $tmpl_renew_product_array as $key => $val ) {
			$tmpl_renew_product_array = explode( '=',$val );
			$tmpl_item_id[] = (isset( $tmpl_renew_product_array[1] ))?$tmpl_renew_product_array[1]:'';
			$tmpl_slug[ (isset( $tmpl_renew_product_array[1] ))?$tmpl_renew_product_array[1]:'' ] = (isset( $tmpl_renew_product_array[0] ))?$tmpl_renew_product_array[0]:'';
			$tmpl_invoice_id[ (isset( $tmpl_renew_product_array[1] ))?$tmpl_renew_product_array[1]:'' ] = (isset( $tmpl_renew_product_array[2] ))?$tmpl_renew_product_array[2]:'';
			$tmpl_invoice_item_id[ (isset( $tmpl_renew_product_array[1] ))?$tmpl_renew_product_array[1]:'' ] = (isset( $tmpl_renew_product_array[3] ))?$tmpl_renew_product_array[3]:'';
		}
		if ( (is_network_admin() || ! is_multisite() ) && in_array( TEVOLUTION_CLASSIFIEDS_SLUG,$tmpl_slug ) ) {
			$key = array_search( TEVOLUTION_CLASSIFIEDS_SLUG, $tmpl_slug );
			add_action( 'after_plugin_row_' . TEVOLUTION_CLASSIFIEDS_SLUG, 'tmpl_notify_tev_classified_renew_product',11 );
		}
		if ( ! function_exists( 'tmpl_notify_tev_classified_renew_product' ) ) {
			function tmpl_notify_tev_classified_renew_product( $plugin_file='', $plugin_data='', $status='' ) {
				$current = get_site_transient( 'update_plugins' );
				$tmpl_renew_product = get_option( 'tmpl_renew_product' );
				$tmpl_renew_product_array = explode( ',',$tmpl_renew_product );

				foreach ( $tmpl_renew_product_array as $key => $val ) {
					$tmpl_renew_product_array = explode( '=',$val );
					$tmpl_item_id[] = $tmpl_renew_product_array[1];
					$tmpl_slug[ $tmpl_renew_product_array[1] ] = $tmpl_renew_product_array[0];
					$tmpl_invoice_id[ $tmpl_renew_product_array[1] ] = $tmpl_renew_product_array[2];
					$tmpl_invoice_item_id[ $tmpl_renew_product_array[1] ] = $tmpl_renew_product_array[3];
				}
				if ( (is_network_admin() || ! is_multisite() ) && in_array( TEVOLUTION_CLASSIFIEDS_SLUG,$tmpl_slug ) ) {
					$key = array_search( TEVOLUTION_CLASSIFIEDS_SLUG, $tmpl_slug );
					echo '<tr class="plugin-update-tr tev-plugin-renew"><td colspan="3" class="plugin-update"><div class="update-message"> ' . __( 'Your Membership has been expired. You can Renew it from ','templatic-admin' ) . '<span style="color: #0073aa; cursor: pointer;" id="tmpl_redirect" target="_blank" data-key="' . $key . '" data-invoice-id="' . $tmpl_invoice_id[ $key ] . '" data-invoice-item-id="' . $tmpl_invoice_item_id[ $key ] . '" class="thickbox" title="Templatic renew">' . __( 'Here','templatic-admin' ) . '</span></div></td></tr>';

				}
				 add_action( 'admin_footer','tmpl_redirect_temp' );
			}
		}
	}// End if().
} else {
	add_action( 'admin_notices','tmpl_classifieds_admin_notices' );
}// End if().
/* Show the notice if tevolution classifieds plug in is not activated. */

function tmpl_classifieds_admin_notices() {
	echo '<div class="error"><p>' . __( 'You have not activated the base plug in <b>Tevolution</b>. Please activate it to use Tevolution-Classifieds plug in.','classifieds' ) . '</p></div>';
}
/*action to include sample data file*/
add_action( 'admin_init','insert_classified_sample_data',20 );
function insert_classified_sample_data() {
	remove_action( 'after_plugin_row_Tevolution-Classifieds/classifieds.php', 'wp_plugin_update_row' ,10, 2 );
	
	// Remove price field while we quick edit classified from the backend.
    remove_action( 'quick_edit_custom_box', 'category_price_show', 10, 2 );
	
	/* file to insert classified listing and set up widget in its sidebar */
	if ( is_admin() && (isset( $_REQUEST['classified_dummy'] ) && $_REQUEST['classified_dummy'] != '') ) {
		include( TEVOLUTION_CLASSIFIEDS_DIR . 'classifieds/classified_auto_install_xml.php' );
	}
}
/* classifieds right widget area */
add_action( 'before-footer-content','tmpl_classifieds_footer' );
/* footer right widget area */
function tmpl_classifieds_footer() {
	if ( is_active_sidebar( 'footer_right' ) ) {
		dynamic_sidebar( 'footer_right' );
	}
}

/* Compatibility with front end editor */

add_filter( 'frontend_supported_post_type','tmpl_frontend_supported_post_type' );

function tmpl_frontend_supported_post_type( $post_types ) {

	return array_merge( array( 'classified' ),$post_types );
}

$included_files = get_included_files();

foreach ( $included_files as $filename ) {
	if ( strstr( $filename,'Tevolution-Classifieds' ) ) {
		/*echo $filename."<br/>";*/
	}
}

register_activation_hook( __FILE__, 'tmpl_classified_plugin_activate' );

/* Hook to Insert the options on plugin activation */
function tmpl_classified_plugin_activate() {
	global $wpdb,$pagenow;
	if ( $pagenow == 'themes.php' || $pagenow == 'theme-install.php' ) {

		update_option( 'classified_auto_install','true' );

		$templatic_settings = get_option( 'templatic_settings' );
		$settings = array(
			'sorting_option' => array( 'title_alphabetical', 'date_asc', 'date_desc', 'random', 'rating', 'reviews', 'title_asc', 'title_desc', 'classifieds_price_low_high', 'classifieds_price_high_low' ),
			'default_page_view' => 'listview',
		);

		/* add propety from homepage settings in tevolution when deactivate */
		if ( empty( $templatic_settings['home_listing_type_value'] ) ) {
			$home_listing_type = array(
				'home_listing_type_value' => array( 'classified' ),
			);
			$settings = array_merge( $settings,$home_listing_type );
		}

		if ( empty( $templatic_settings ) ) {
			update_option( 'templatic_settings',$settings );
		} else {
			update_option( 'templatic_settings',array_merge( $templatic_settings,$settings ) );
		}
		/* add rule for urls */
		$tevolution_taxonomies_data1 = get_option( 'tevolution_taxonomies_rules_data' );
		$tevolution_taxonomies_data1['tevolution_single_post_add']['classified'] = 'classified';
		update_option( 'tevolution_taxonomies_rules_data',$tevolution_taxonomies_data1 );
		if ( function_exists( 'tevolution_taxonimies_flush_event' ) ) {
			tevolution_taxonimies_flush_event();
		}
		/* Delete Tevolution query catch on permalink update  changes */
		$wpdb->query( $wpdb->prepare( "DELETE FROM $wpdb->options WHERE option_name like '%s'",'%_tevolution_quer_%' ) );
		update_option( 'classified_redirect_activation','Active' );
	} else {
		update_option( 'classified_auto_install','false' );
	}// End if().
}
/*
 * Plugin Deactivation hook
 */
register_deactivation_hook( __FILE__,'unregister_classified_fields' );
function unregister_classified_fields() {
	 $post_type = get_option( 'templatic_custom_post' );
	 $taxonomy = get_option( 'templatic_custom_taxonomy' );
	 $tag = get_option( 'templatic_custom_tags' );
	 $taxonomy_slug = $post_type['classified']['slugs'][0];
	 $tag_slug = $post_type['classified']['slugs'][1];
	 /*unset classified post type and its taxonomy at the time of plugin deactivation*/
	 unset( $post_type['classified'] );
	 unset( $taxonomy[ $taxonomy_slug ] );
	 unset( $tag[ $tag_slug ] );

	/* remove classified from homepage settings in tevolution when deactivate */
	 $templatic_settings = get_option( 'templatic_settings' );
	if ( ! empty( $templatic_settings['home_listing_type_value'] ) ) {
		if ( in_array( 'classified',$templatic_settings['home_listing_type_value'] ) ) {
			$settings = array_diff( $templatic_settings['home_listing_type_value'],array( 'classified' ) );
		}
	}
	if ( empty( $templatic_settings ) ) {
		 update_option( 'templatic_settings',$settings );
	} else {
		$templatic_settings['home_listing_type_value'] = $settings;
		$final_array = array_merge( $templatic_settings,$settings );
		 update_option( 'templatic_settings',$final_array );
	}

	 update_option( 'templatic_custom_post',$post_type );
	 update_option( 'templatic_custom_taxonomy',$taxonomy );
	 update_option( 'templatic_custom_tags',$tag );
	 update_option( 'tevolution_classifieds','' );

	 delete_option( 'hide_classified_ajax_notification' );
	 delete_option( 'property_custom_fields_insert' );
	 delete_option( 'event_manager_redirect_activation' );
	 delete_option( 'property_location_post_type' );
}

/*
 * Update tevolution plugin version after templatic member login
 */
add_action( 'wp_ajax_classified','classified_update_login' );
function classified_update_login() {
	check_ajax_referer( 'classified', '_ajax_nonce' );
	$plugin_dir = rtrim( plugin_dir_path( __FILE__ ), '/' );
	require_once( $plugin_dir . '/templatic_login.php' );
	exit;
}

add_action( 'init', 'classified_register_image_sizes' );
function classified_register_image_sizes() {
	add_image_size( 'clasified-thumb', 250, 165, true );
}
/*save ad_id while save classified*/
add_action( 'save_post_classified','save_classified_data' );
add_action( 'process_coupons','save_classified_data',99 );
function save_classified_data( $last_postid ) {
	if ( get_post_meta( $last_postid,'ad_id',true ) == '' || get_post_meta( $last_postid,'ad_id',true ) <= 0 ) {
		update_post_meta( $last_postid,'ad_id',rand( 1000, 9999 ) . $last_postid );
	}
}

add_action( 'admin_init','tmpl_classified_show_items_inmenu' );
/* make category and tags checked by default in menu section under screen options */
function tmpl_classified_show_items_inmenu() {

	if ( get_option( 'select_cat_classified_option' ) != 'Active' ) {
		$hidden_nav_boxes = get_user_option( 'metaboxhidden_nav-menus' );

		$post_type = 'classifieds'; //Can also be a taxonomy slug
		$post_type_nav_box = 'add-post-type-' . $post_type;

		if ( @in_array( $post_type_nav_box, $hidden_nav_boxes ) ) :
			foreach ( $hidden_nav_boxes as $i => $nav_box ) :
				if ( $nav_box == $post_type_nav_box ) {
					unset( $hidden_nav_boxes[ $i ] );
				}
			endforeach;
			update_user_option( get_current_user_id(), 'metaboxhidden_nav-menus', $hidden_nav_boxes );
		endif;

		$classifieds_cat = 'classifiedscategory'; //Can also be a taxonomy slug
		$post_type_nav_box = 'add-' . $classifieds_cat;

		if ( @in_array( $post_type_nav_box, $hidden_nav_boxes ) ) :
			foreach ( $hidden_nav_boxes as $i => $nav_box ) :
				if ( $nav_box == $post_type_nav_box ) {
					unset( $hidden_nav_boxes[ $i ] );
				}
			endforeach;
			update_user_option( get_current_user_id(), 'metaboxhidden_nav-menus', $hidden_nav_boxes );
		endif;

		 $classifieds_tag = 'classifiedstags'; //Can also be a taxonomy slug
		$post_type_nav_box = 'add-' . $classifieds_tag;

		if ( @in_array( $post_type_nav_box, $hidden_nav_boxes ) ) :
			foreach ( $hidden_nav_boxes as $i => $nav_box ) :
				if ( $nav_box == $post_type_nav_box ) {
					unset( $hidden_nav_boxes[ $i ] );
				}
			endforeach;
			update_user_option( get_current_user_id(), 'metaboxhidden_nav-menus', $hidden_nav_boxes );
		endif;
		update_option( 'select_cat_classified_option','Active' );
	}// End if().
}

