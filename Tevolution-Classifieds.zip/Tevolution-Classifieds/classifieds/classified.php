<?php
/*
 Register classified taxonomy.
*/
	define( 'CUSTOM_POST_TYPE_CLASSIFIED','classified' );
	define( 'CUSTOM_CATEGORY_TYPE_CLASSIFIED','classifiedscategory' );
	define( 'CUSTOM_TAG_TYPE_CLASSIFIED','classifiedstags' );
	define( 'CUSTOM_MENU_CLASSIFIED_TITLE',__( 'Classifieds','classifieds' ) );
	define( 'CUSTOM_MENU_CLASSIFIED_NAME',__( 'Classifieds','classifieds' ) );
	define( 'CUSTOM_MENU_CLASSIFIED_SIGULAR_NAME',__( 'Classified','classifieds' ) );
	define( 'CUSTOM_MENU_CLASSIFIED_ADD_NEW',__( 'Add Classified','classifieds' ) );
	define( 'CUSTOM_MENU_CLASSIFIED_NEW_ITEM',__( 'Add Classified','classifieds' ) );
	define( 'CUSTOM_MENU_CLASSIFIED_EDIT',__( 'Edit','classifieds' ) );
	define( 'CUSTOM_MENU_CLASSIFIED_EDIT_ITEM',__( 'Edit Classified','classifieds' ) );
	define( 'CUSTOM_MENU_CLASSIFIED_NEW',__( 'New Classified','classifieds' ) );
	define( 'CUSTOM_MENU_CLASSIFIED_VIEW',__( 'View Classified','classifieds' ) );
	define( 'CUSTOM_MENU_CLASSIFIED_SEARCH',__( 'Search Classified','classifieds' ) );
	define( 'CUSTOM_MENU_CLASSIFIED_NOT_FOUND',__( 'No Classified found','classifieds' ) );
	define( 'CUSTOM_MENU_CLASSIFIED_NOT_FOUND_TRASH',__( 'No Classified found in trash','classifieds' ) );
	define( 'CUSTOM_MENU_CLASSIFIED_CAT_LABEL',__( 'Classified Categories','classifieds' ) );
	define( 'CUSTOM_MENU_CLASSIFIED_CAT_TITLE',__( 'Classified Categories','classifieds' ) );
	define( 'CUSTOM_MENU_CLASSIFIED_SIGULAR_CAT',__( 'Classified Categories','classifieds' ) );
	define( 'CUSTOM_MENU_CLASSIFIED_CAT_SEARCH',__( 'Search category','classifieds' ) );
	define( 'CUSTOM_MENU_CLASSIFIED_CAT_POPULAR',__( 'Popular categories','classifieds' ) );
	define( 'CUSTOM_MENU_CLASSIFIED_CAT_ALL',__( 'All categories','classifieds' ) );
	define( 'CUSTOM_MENU_CLASSIFIED_CAT_PARENT',__( 'Parent category','classifieds' ) );
	define( 'CUSTOM_MENU_CLASSIFIED_CAT_PARENT_COL',__( 'Parent category:','classifieds' ) );
	define( 'CUSTOM_MENU_CLASSIFIED_CAT_EDIT',__( 'Edit category','classifieds' ) );
	define( 'CUSTOM_MENU_CLASSIFIED_CAT_UPDATE',__( 'Update category','classifieds' ) );
	define( 'CUSTOM_MENU_CLASSIFIED_CAT_ADDNEW',__( 'Add new category','classifieds' ) );
	define( 'CUSTOM_MENU_CLASSIFIED_CAT_NEW_NAME',__( 'New category name','classifieds' ) );
	define( 'CUSTOM_MENU_TAG_LABEL_CLASSIFIED',__( 'Classified Tags','classifieds' ) );
	define( 'CUSTOM_MENU_TAG_TITLE_CLASSIFIED',__( 'Classified Tags','classifieds' ) );
	define( 'CUSTOM_MENU_TAG_SEARCH_CLASSIFIED',__( 'Classified Tags','classifieds' ) );
	define( 'CUSTOM_MENU_TAG_POPULAR_CLASSIFIED',__( 'Popular Classified tags','classifieds' ) );
	define( 'CUSTOM_MENU_TAG_ALL_CLASSIFIED',__( 'All Classified tags','classifieds' ) );
	define( 'CUSTOM_MENU_TAG_PARENT_CLASSIFIED',__( 'Parent Classified tags','classifieds' ) );
	define( 'CUSTOM_MENU_TAG_PARENT_COL_CLASSIFIED',__( 'Parent Classified tags:','classifieds' ) );
	define( 'CUSTOM_MENU_TAG_EDIT_CLASSIFIED',__( 'Edit Classified tags','classifieds' ) );
	define( 'CUSTOM_MENU_TAG_UPDATE_CLASSIFIED',__( 'Update Classified tags','classifieds' ) );
	define( 'CUSTOM_MENU_TAG_ADD_NEW_CLASSIFIED',__( 'Add new Classified tags','classifieds' ) );
	define( 'CUSTOM_MENU_TAG_NEW_ADD_CLASSIFIED',__( 'New Classified tag name','classifieds' ) );
	/*custom field information title*/
	define( 'CLASSIFIED_CUSTOM_INFORMATION',__( 'Classified Custom Information','classifieds' ) );
if ( ! defined( 'CUSTOM_INFORMATION' ) ) { define( 'CUSTOM_INFORMATION',__( 'Custom Information','classifieds' ) );
}
	define( 'CLASSIFIED_TITLE_HEAD',__( 'Title','classifieds' ) );
	define( 'CLASSIFIED_TYPE_TEXT',__( 'Classified type','classifieds' ) );
	define( 'ADDRESS',__( 'Address','classifieds' ) );
	define( 'CATGORIES_TEXT',__( 'Categories','classifieds' ) );
	define( 'TAGS_TEXT_HEAD',__( 'Tags','classifieds' ) );
	/*Attend Classified message and text  */
	define( 'ATTEND_CLASSIFIED_MSG',__( 'are you going to attend','classifieds' ) );
	define( 'REMOVE_CLASSIFIED_MSG',__( 'You are going to attend','classifieds' ) );
	define( 'ATTEND_CLASSIFIED_TEXT',__( 'Yes, I am','classifieds' ) );
	define( 'REMOVE_CLASSIFIED_TEXT',__( 'Not attending now.','classifieds' ) );

add_action( 'init','register_classified_post_type',0 );

function register_classified_post_type() {
	if ( get_option( 'classified_auto_install' ) == 'true' || (is_admin() && defined( 'DOING_AJAX' ) && DOING_AJAX ) ) :
		include( TEVOLUTION_CLASSIFIEDS_DIR . 'classifieds/install.php' );
	endif;
}

/* Hook to perform auto install */
add_action( 'admin_head','tmpl_classified_auto_install' );

if ( ! function_exists( 'tmpl_classified_auto_install' ) ) {
	function tmpl_classified_auto_install() {
		global $pagenow;
		if ( get_option( 'tmpl_is_tev_auto_insall' ) == 'true' && get_option( 'classified_auto_install' ) != 'true' && get_option( 'classified_auto_install' ) != '' ) :

			/* If plugin page display auto install process */
			if ( $pagenow == 'plugins.php' ) :
				echo '<div id="auto_install_html" class="notice notice-info is-dismissible">
			<p>
				<strong id="custom_message"></strong>
				<img id="install_loader" src="' . TEVOLUTION_CLASSIFIEDS_URL . 'images/install_loader.gif">
			</p>
		</div>';
		endif;

			/* Action array to define auto intall process steps */
			$process_array[] = array(
				'action' => 'tmpl_insert_classified_data',
				'message' => __( 'Setting up classified default options...','templatic-admin' ),
			);

			/* ajax url for auto install process */
			$ajax_url = esc_js( get_bloginfo( 'wpurl' ) . '/wp-admin/admin-ajax.php' );
			$counter = 1;
			$total_step = count( $process_array );
			echo '<script async type="text/javascript">window.onload = function () {
			jQuery("#auto_install_html .notice-dismiss").remove();';

			/* Call first step function on load */
			echo 'action_' . $process_array[0]['action'] . '();';

			/* Loop through all process */
			foreach ( $process_array as $process ) {
				$script_code = 'function action_' . $process['action'] . '(){ 
				jQuery("#custom_message").html("' . $process['message'] . '");
				jQuery.ajax({
				url:"' . $ajax_url . '",
				type:"POST",
				data:"action=' . $process['action'] . '&auto_install=yes",
				success:function(results) {
					setTimeout(
					  function() 
					  {  
					';
				if ( $total_step != $counter ) {
					$script_code .= 'action_' . $process_array[ $counter ]['action'] . '();';
				} else {
					$script_code .= 'action_tmpl_classified_finish_install();';
					$script_code .= 'jQuery("#install_loader").remove();';
				}
					$script_code .= '}, 1000);
				}
			});
		}';
				echo $script_code;
				$counter++;
			}
			echo 'function action_tmpl_classified_finish_install(){
		jQuery("#auto_install_html").remove();
		jQuery.ajax({
			url:"' . $ajax_url . '",
			type:"POST",
			data:"action=tmpl_classified_finish_default_install",
			success:function(results) {';
			if ( $pagenow == 'plugins.php' ) :
				echo 'location.reload();';
				endif;
			echo '}
	}); }';
			echo '}</script>';
			else :
				update_option( 'classified_auto_install','true' );
			endif;
	}
}// End if().


/* Install listings auto install data */
add_action( 'wp_ajax_tmpl_insert_classified_data', 'tmpl_create_classified_auto_install_data' );
add_action( 'wp_ajax_tmpl_insert_classified_data', 'register_classified_post_type' );


if ( ! function_exists( 'tmpl_create_classified_auto_install_data' ) ) {
	function tmpl_create_classified_auto_install_data() {
		global $wpdb;
		$templatic_settings = get_option( 'templatic_settings' );
		$settings = array(
			'sorting_option' => array( 'title_alphabetical', 'date_asc', 'date_desc', 'random', 'rating', 'reviews', 'title_asc', 'title_desc', 'classifieds_price_low_high', 'classifieds_price_high_low' ),
			'default_page_view' => 'listview',
		);

		 /* add propety from homepage settings in tevolution when deactivate */
		if ( empty( $templatic_settings['home_listing_type_value'] ) ) {
			$home_listing_type = array(
				'home_listing_type_value' => array( 'classified' ),
			);
			$settings = array_merge( $settings,$home_listing_type );
		}

		if ( empty( $templatic_settings ) ) {
			update_option( 'templatic_settings',$settings );
		} else {
			update_option( 'templatic_settings',array_merge( $templatic_settings,$settings ) );
		}
			/* add rule for urls */
			$tevolution_taxonomies_data1 = get_option( 'tevolution_taxonomies_rules_data' );
			$tevolution_taxonomies_data1['tevolution_single_post_add']['classified'] = 'classified';
			update_option( 'tevolution_taxonomies_rules_data',$tevolution_taxonomies_data1 );
		if ( function_exists( 'tevolution_taxonimies_flush_event' ) ) {
			tevolution_taxonimies_flush_event();
		}
			/* Delete Tevolution query catch on permalink update  changes */
			$wpdb->query( $wpdb->prepare( "DELETE FROM $wpdb->options WHERE option_name like '%s'",'%_tevolution_quer_%' ) );
			update_option( 'classified_redirect_activation','Active' );
			exit;
	}
}// End if().

/* Complete listing auto install */
add_action( 'wp_ajax_tmpl_classified_finish_default_install', 'tmpl_finish_classified_auto_install_data' );
if ( ! function_exists( 'tmpl_finish_classified_auto_install_data' ) ) {
	function tmpl_finish_classified_auto_install_data() {
		update_option( 'classified_auto_install','true' );
		exit;
	}
}

