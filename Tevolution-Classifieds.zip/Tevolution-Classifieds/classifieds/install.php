<?php
/* Register classified taxonomy */
global $wpdb,$pagenow;
$classified_post_type = 0;
$custom_post_type = CUSTOM_POST_TYPE_CLASSIFIED;
$custom_cat_type = CUSTOM_CATEGORY_TYPE_CLASSIFIED;
$custom_tag_type = CUSTOM_TAG_TYPE_CLASSIFIED;
$custom_post_types_args = array();
if ( function_exists( 'tevolution_get_post_type' ) ) {
	$post_type_array = tevolution_get_post_type();
} else {
	$post_type_array = get_post_types( $custom_post_types_args,'objects' );
}
if ( isset( $_POST['reset_custom_fields'] ) && (isset( $_POST['custom_reset'] ) && $_POST['custom_reset'] == 1) ) {
	update_option( 'classified_custom_fields_insert','none' );
}
/*
 * Function Name: tevolution_classified_taxonomy_msg
 *
 */
if ( ! function_exists( 'tevolution_classified_taxonomy_msg' ) ) {
	function tevolution_classified_taxonomy_msg() {
		echo '<div id="message" class="error below-h2">';
		echo '<form action="" method="post">';
		echo "<p class='tevolution_desc'>" . __( 'You have no classified post type now but your classified-manager is in active status so you can generate classified post type again. ','classifieds' );
		echo '<input type="submit" name="classified_post_type" value="' . __( 'Generate Classifieds Taxonomy','classifieds' ) . '" class="button-primary">';
		echo '</p>';
		echo '<form>';
		echo '</div>';
	}
}

if ( (isset( $_REQUEST['page'] ) && $_REQUEST['page'] == 'custom_setup') && (isset( $_POST['classified_post_type'] )) ) {
	$cls_post_type = 1;
}

/* Insert Post heading type into posts which user can not delete
   Note: don't delete this code or change it.
*/

global $wpdb,$pagenow,$table_name;

$post_city_id = $wpdb->get_row( "SELECT post_title,ID FROM $wpdb->posts WHERE $wpdb->posts.post_name = 'post_city_id' and $wpdb->posts.post_type = 'custom_fields'" );

if ( get_post_meta( $post_city_id->ID,'classified_heading_type',true ) ) {
	update_post_meta( $post_city_id->ID, 'classified_heading_type',get_post_meta( $post_city_id->ID,'classified_heading_type',true ) );
} else {
	update_post_meta( $post_city_id->ID, 'classified_heading_type','Locations & Map' );
}
	
	
if ( ($pagenow == 'plugins.php' || $pagenow == 'themes.php' ||  (isset( $_REQUEST['page'] ) && ($_REQUEST['page'] == 'custom_setup' || $_REQUEST['ctab'] == 'custom_fields' ))) ) {

	/* Insert Post heading type into posts */
	$taxonomy_name = $wpdb->get_row( "SELECT post_title,ID FROM $wpdb->posts WHERE $wpdb->posts.post_title = '[#taxonomy_name#]' and $wpdb->posts.post_type = 'custom_fields'" );
	if ( count( $taxonomy_name ) != 0 ) {
		$post_type = get_post_meta( $taxonomy_name->ID, 'post_type',true );
		if ( ! strstr( $post_type,'classified' ) ) {
			update_post_meta( $taxonomy_name->ID, 'post_type',$post_type . ',classified' );
		}

		update_post_meta( $taxonomy_name->ID, 'is_submit_field',1 );
		update_post_meta( $taxonomy_name->ID, 'post_type_classified','classified' );
		update_post_meta( $taxonomy_name->ID, 'taxonomy_type_classifiedscategory','classifiedscategory' );
		update_post_meta( @$taxonomy_name->ID, 'is_submit_field','1' );
		if ( get_post_meta( $taxonomy_name->ID,'classified_sort_order',true ) ) {
			update_post_meta( $taxonomy_name->ID, 'classified_sort_order',get_post_meta( $taxonomy_name->ID,'classified_sort_order',true ) );
		} else {
			update_post_meta( $taxonomy_name->ID, 'classified_sort_order',1 );
		}
	}


	/* Insert Post Category into posts */
	$post_category = $wpdb->get_row( "SELECT post_title,ID FROM $wpdb->posts WHERE $wpdb->posts.post_name = 'category' and $wpdb->posts.post_type = 'custom_fields'" );
	if ( count( $post_category ) != 0 ) {
			$post_type = get_post_meta( $post_category->ID, 'post_type',true );
		if ( ! strstr( $post_type,'classified' ) ) {
			update_post_meta( $post_category->ID, 'post_type',$post_type . ',classified' );
		}

			update_post_meta( $post_category->ID, 'post_type_classified','classified' );
			update_post_meta( $post_category->ID, 'taxonomy_type_classifiedscategory','classifiedscategory' );
			update_post_meta( $post_category->ID, 'show_on_detail','1' );
			update_post_meta( $post_category->ID, 'show_on_listing','1' );
		if ( get_post_meta( $post_category->ID,'classified_sort_order',true ) ) {
			update_post_meta( $post_category->ID, 'classified_sort_order',get_post_meta( $post_category->ID,'classified_sort_order',true ) );
		} else {
			update_post_meta( $post_category->ID, 'classified_sort_order',2 );
		}
		if ( get_post_meta( $post_category->ID,'classified_heading_type',true ) ) {
			update_post_meta( $post_category->ID, 'classified_heading_type',get_post_meta( $post_category->ID,'classified_heading_type',true ) );
		} else {
			update_post_meta( $post_category->ID, 'classified_heading_type','[#taxonomy_name#]' );
		}
	}


	 /* Insert Post heading type into posts */
	 $post_title = $wpdb->get_row( "SELECT post_title,ID FROM $wpdb->posts WHERE $wpdb->posts.post_name = 'post_title' and $wpdb->posts.post_type = 'custom_fields'" );
	if ( count( $post_title ) != 0 ) {
		$post_type = get_post_meta( $post_title->ID, 'post_type',true );
		if ( ! strstr( $post_type,'classified' ) ) {
			update_post_meta( $post_title->ID, 'post_type',$post_type . ',classified' );
		}

		update_post_meta( $post_title->ID, 'post_type_classified','classified' );
		update_post_meta( $post_title->ID, 'taxonomy_type_classifiedscategory','listingcategory' );
		update_post_meta( $post_title->ID, 'is_submit_field','1' );
		if ( get_post_meta( $post_title->ID,'classified_sort_order',true ) ) {
			update_post_meta( $post_title->ID, 'classified_sort_order',get_post_meta( $post_title->ID,'classified_sort_order',true ) );
		} else {
			update_post_meta( $post_title->ID, 'classified_sort_order',3 );
		}
		update_post_meta( $post_title->ID, 'classified_sort_order',3 );

		if ( get_post_meta( $post_title->ID,'classified_heading_type',true ) ) {
			update_post_meta( $post_title->ID, 'classified_heading_type',get_post_meta( $post_title->ID,'classified_heading_type',true ) );
		} else {
			update_post_meta( $post_title->ID, 'classified_heading_type','[#taxonomy_name#]' );
		}
		update_post_meta( $post_title->ID, 'classified_heading_type','[#taxonomy_name#]' );
	}
	/*Insert post image */
	$post_images = $wpdb->get_row( "SELECT post_title,ID FROM $wpdb->posts WHERE $wpdb->posts.post_name = 'post_images' and $wpdb->posts.post_type = 'custom_fields'" );
	if ( count( $post_images ) != 0 ) {
		$post_type = get_post_meta( $post_images->ID, 'post_type',true );
		if ( ! strstr( $post_type,'classified' ) ) {
			update_post_meta( $post_images->ID, 'post_type',$post_type . ',classified' );
		}

		update_post_meta( $post_images->ID, 'post_type_classified','classified' );

		update_post_meta( $post_images->ID, 'taxonomy_type_classifiedscategory','classifiedscategory' );
		if ( get_post_meta( $post_images->ID,'classified_sort_order',true ) ) {
			update_post_meta( $post_images->ID, 'classified_sort_order',get_post_meta( $post_images->ID,'classified_sort_order',true ) );
		} else {
			update_post_meta( $post_images->ID, 'classified_sort_order',14 );
		}
		if ( get_post_meta( $post_images->ID,'classified_heading_type',true ) ) {
			update_post_meta( $post_images->ID, 'classified_heading_type',get_post_meta( $post_images->ID,'classified_heading_type',true ) );
		} else {
			update_post_meta( $post_images->ID, 'classified_heading_type','Label Of Field' );
		}
	}
}// End if().
	 /* to display city informations on detail page */
if ( (isset( $_REQUEST['ctab'] ) && $_REQUEST['ctab'] == 'custom_fields' && (isset( $_POST['reset_custom_fields'] ) && $_REQUEST['post_type_fields'] == CUSTOM_POST_TYPE_CLASSIFIED)) || ((isset( $_REQUEST['page'] ) && $_REQUEST['page'] == 'templatic_system_menu') || $pagenow == 'themes.php' || $pagenow == 'plugins.php') && ( ! in_array( CUSTOM_POST_TYPE_CLASSIFIED,$post_type_array ) && strtolower( get_option( 'tevolution_classifieds' ) ) != strtolower( 'Active' )) || (isset( $cls_post_type ) && $cls_post_type == 1) ) {

	update_option( 'tevolution_classifieds','Active' );

	$post_arr_merge[ $custom_post_type ] = array(
	'label' 			=> CUSTOM_MENU_CLASSIFIED_SIGULAR_NAME,
						'labels' 			=> array(
												'name' 				 => CUSTOM_MENU_CLASSIFIED_SIGULAR_NAME,
												'singular_name'  	 => CUSTOM_MENU_CLASSIFIED_SIGULAR_NAME,
												'menu_name'  	 	 => CUSTOM_MENU_CLASSIFIED_TITLE,
												'add_new' 			 => CUSTOM_MENU_CLASSIFIED_ADD_NEW,
												'add_new_item' 		 => CUSTOM_MENU_CLASSIFIED_NEW_ITEM,
												'edit' 				 => CUSTOM_MENU_CLASSIFIED_EDIT,
												'edit_item' 		 => CUSTOM_MENU_CLASSIFIED_EDIT_ITEM,
												'new_item' 			 => CUSTOM_MENU_CLASSIFIED_NEW,
												'view_item'			 => CUSTOM_MENU_CLASSIFIED_VIEW,
												'search_items' 		 => CUSTOM_MENU_CLASSIFIED_SEARCH,
												'not_found' 		 => CUSTOM_MENU_CLASSIFIED_NOT_FOUND,
												'not_found_in_trash' => CUSTOM_MENU_CLASSIFIED_NOT_FOUND_TRASH,
				),
						'public' 			=> true,
						'has_archive'       => true,
						'can_export'		=> true,
						'show_ui' 			=> true, /* SHOW UI IN ADMIN PANEL */
						'_builtin' 			=> false, /* IT IS A CUSTOM POST TYPE NOT BUILT IN */
						'_edit_link' 		=> 'post.php?post=%d',
						'capability_type' 	=> 'post',

						'menu_icon' 		=> TEMPL_PLUGIN_URL . 'images/templatic-logo.png',
						'hierarchical' 		=> false,
						'rewrite' 			=> array(
							'slug' => "$custom_post_type",
						), /* PERMALINKS TO EVENT POST TYPE */
						'query_var' 		=> "$custom_post_type", /* THIS GOES TO WPQUERY SCHEMA */
						'supports' 			=> array( 'title', 'author','excerpt','thumbnail','comments','editor','trackbacks','custom-fields','revisions' ),
						'show_in_nav_menus'	=> true,
						'slugs'				=> array( "$custom_cat_type","$custom_tag_type" ),
						'taxonomies'		=> array( CUSTOM_MENU_CLASSIFIED_CAT_TITLE,CUSTOM_MENU_TAG_LABEL_CLASSIFIED ),

				);
				$original = get_option( 'templatic_custom_post' );
	if ( $original ) {
		$post_arr_merge = array_merge( $original,$post_arr_merge );
	}

				ksort( $post_arr_merge );
				update_option( 'templatic_custom_post',$post_arr_merge );
	/* EOF - REGISTER classified POST TYPE */

	/* REGISTER CUSTOM TAXONOMY FOR POST TYPE classified */
	$original = array();

	$taxonomy_arr_merge[ $custom_cat_type ] = array(
	'hierarchical' 	=> true,
						'label' 		=> CUSTOM_MENU_CLASSIFIED_CAT_LABEL,
						'post_type'		=> $custom_post_type,
						'post_slug'		=> $custom_post_type,
						'labels' 		=> array(
												'name' 				=> CUSTOM_MENU_CLASSIFIED_CAT_TITLE,
												'singular_name' 	=> $custom_cat_type,
												'search_items' 		=> CUSTOM_MENU_CLASSIFIED_CAT_SEARCH,
												'popular_items' 	=> CUSTOM_MENU_CLASSIFIED_CAT_SEARCH,
												'all_items' 		=> CUSTOM_MENU_CLASSIFIED_CAT_ALL,
												'parent_item' 		=> CUSTOM_MENU_CLASSIFIED_CAT_PARENT,
												'parent_item_colon' => CUSTOM_MENU_CLASSIFIED_CAT_PARENT_COL,
												'edit_item' 		=> CUSTOM_MENU_CLASSIFIED_CAT_EDIT,
												'update_item'		=> CUSTOM_MENU_CLASSIFIED_CAT_UPDATE,
												'add_new_item' 		=> CUSTOM_MENU_CLASSIFIED_CAT_ADDNEW,
												'new_item_name' 	=> CUSTOM_MENU_CLASSIFIED_CAT_NEW_NAME,
				),
						'public' 		=> true,
						'show_ui' 		=> true,
						'rewrite' 		 => array(
							'slug' => "$custom_cat_type",
						), /* PERMALINKS TO EVENT POST TYPE */
				);
				$original = get_option( 'templatic_custom_taxonomy' );
	if ( $original ) {
		$taxonomy_arr_merge = array_merge( $original,$taxonomy_arr_merge );
	}
				/*register_taxonomy($custom_cat_type,array($custom_post_type),$taxonomy_arr_merge[$custom_cat_type]);*/
				ksort( $taxonomy_arr_merge );
				update_option( 'templatic_custom_taxonomy',$taxonomy_arr_merge );

				$tevolution_taxonomy_marker = get_option( 'tevolution_taxonomy_marker' );
	if ( empty( $tevolution_taxonomy_marker ) ) {
		update_option( 'tevolution_taxonomy_marker',array(
			$custom_cat_type => 'enable',
		) );
	} else {
		update_option( 'tevolution_taxonomy_marker',array_merge( $tevolution_taxonomy_marker,array(
			$custom_cat_type => 'enable',
		) ) );
	}
	/*EOF - REGISTER CUSTOM TAXONOMY FOR POST TYPE EVENT */

	/* register tag for post type event */
	$tag_arr_merge = array();
	$tag_arr_merge[ $custom_tag_type ] =
				array(
	'hierarchical' 	=> false,
						'label' 		=> CUSTOM_MENU_TAG_LABEL_CLASSIFIED,
						'post_type'		=> $custom_post_type,
						'post_slug'		=> $custom_post_type,
						'labels' 		=> array(
												'name' 				=> CUSTOM_MENU_TAG_TITLE_CLASSIFIED,
												'singular_name' 	=> $custom_tag_type,
												'search_items' 		=> CUSTOM_MENU_TAG_SEARCH_CLASSIFIED,
												'popular_items' 	=> CUSTOM_MENU_TAG_POPULAR_CLASSIFIED,
												'all_items' 		=> CUSTOM_MENU_TAG_ALL_CLASSIFIED,
												'parent_item' 		=> CUSTOM_MENU_TAG_PARENT_CLASSIFIED,
												'parent_item_colon' => CUSTOM_MENU_TAG_PARENT_COL_CLASSIFIED,
												'edit_item' 		=> CUSTOM_MENU_TAG_EDIT_CLASSIFIED,
												'update_item'		=> CUSTOM_MENU_TAG_UPDATE_CLASSIFIED,
												'add_new_item' 		=> CUSTOM_MENU_TAG_ADD_NEW_CLASSIFIED,
												'new_item_name' 	=> CUSTOM_MENU_TAG_NEW_ADD_CLASSIFIED,
				),
						'public' 		=> true,
						'show_ui' 		=> true,
						'rewrite' 		 => array(
							'slug' => "$custom_tag_type",
						), /* PERMALINKS TO classified POST TYPE */
				);
				$original = get_option( 'templatic_custom_tags' );
	if ( $original ) {
		$tag_arr_merge = array_merge( $original,$tag_arr_merge );
	}
				ksort( $tag_arr_merge );
				update_option( 'templatic_custom_tags',$tag_arr_merge );

}// End if().
/*
 * display classified taxonomy generate when classified taxonomy not exists
 */
$post_type_arra = get_option( 'templatic_custom_post',@$post_arr_merge );
if ( ! array_key_exists( 'classified',$post_type_arra ) ) {
	add_action( 'tevolution_custom_taxonomy_msg','tevolution_classified_taxonomy_msg' );
}

/* Insert default custom fields which are not deletable*/

global $wpdb,$pagenow,$table_name;
if ( ($pagenow == 'plugins.php' || $pagenow == 'themes.php' ||  (isset( $_REQUEST['page'] ) && ($_REQUEST['page'] == 'custom_setup' || $_REQUEST['ctab'] == 'custom_fields' ))) ) {
	/* Insert Post excerpt into posts */
	$post_excerpt = $wpdb->get_row( "SELECT post_title,ID FROM $wpdb->posts WHERE $wpdb->posts.post_name = 'post_excerpt' and $wpdb->posts.post_type = 'custom_fields'" );
	if ( count( $post_excerpt ) != 0 ) {
		 $post_type = get_post_meta( $post_excerpt->ID, 'post_type',true );
		if ( ! strstr( $post_type,'classified' ) ) {
			update_post_meta( $post_excerpt->ID, 'post_type',$post_type . ',classified' );
		}

			update_post_meta( $post_excerpt->ID, 'show_on_listing','1' );
			update_post_meta( $post_excerpt->ID, 'post_type_classified','classified' );
			update_post_meta( $post_excerpt->ID, 'taxonomy_type_classifiedscategory','classifiedscategory' );
		if ( get_post_meta( $post_excerpt->ID,'classified_sort_order',true ) ) {
			update_post_meta( $post_excerpt->ID, 'classified_sort_order',get_post_meta( $post_excerpt->ID,'classified_sort_order',true ) );
		} else {
			update_post_meta( $post_excerpt->ID, 'classified_sort_order',13 );
		}
		if ( get_post_meta( $post_excerpt->ID,'classified_heading_type',true ) ) {
			update_post_meta( $post_excerpt->ID, 'classified_heading_type',get_post_meta( $post_excerpt->ID,'classified_heading_type',true ) );
		} else {
			update_post_meta( $post_excerpt->ID, 'classified_heading_type','Classified Information' );
		}
	}
	/* Insert Post content into posts */
	$post_content = $wpdb->get_row( "SELECT post_title,ID FROM $wpdb->posts WHERE $wpdb->posts.post_name = 'post_content' and $wpdb->posts.post_type = 'custom_fields'" );
	if ( count( $post_content ) != 0 ) {
		$post_type = get_post_meta( $post_content->ID, 'post_type',true );
		if ( ! strstr( $post_type,'classified' ) ) {
			update_post_meta( $post_content->ID, 'post_type',$post_type . ',classified' );
		}

		update_post_meta( $post_content->ID, 'post_type_classified','classified' );
		update_post_meta( $post_content->ID, 'taxonomy_type_classifiedscategory','classifiedscategory' );

		if ( ! get_post_meta( $post_content->ID,'classified_sort_order',true ) ) {
			update_post_meta( $post_content->ID, 'classified_sort_order',13 );
		}

		if ( get_post_meta( $post_content->ID,'classified_heading_type',true ) ) {
			update_post_meta( $post_content->ID, 'classified_heading_type',get_post_meta( $post_content->ID,'classified_heading_type',true ) );
		} else {
			update_post_meta( $post_content->ID, 'classified_heading_type','Classified Information' );
		}
	}
}// End if().
/* Insert the classifeids specific custom fields which user can delete/edit */

if ( ((isset( $_REQUEST['page'] ) && (($_REQUEST['page'] == 'custom_fields' || $_REQUEST['page'] == 'templatic_system_menu'))) || $pagenow == 'themes.php' || $pagenow == 'plugins.php')  || get_option( 'classified_custom_fields_insert' ) != 'inserted' || (isset( $_REQUEST['activated'] ) && $_REQUEST['activated'] == 'tevolution_classifieds') || (isset( $_POST['post_type_fields'] ) && $_POST['post_type_fields'] == 'classified') ) {
	update_option( 'classified_custom_fields_insert','inserted' );
	/*Reset tevolution Custom Fields */
	if ( isset( $_POST['post_type_fields'] ) && (isset( $_POST['posttype_fld_reset'] ) && $_POST['posttype_fld_reset'] == 1) ) {
			
		/* Reset the listing custom fields - when click on reset listing custom fields */
		if ( isset( $_REQUEST['posttype_fld_reset'] ) && $_REQUEST['posttype_fld_reset'] == 1 ) {
			$args = array(
			'post_type'      => 'custom_fields',
			  'posts_per_page' => -1,
			  'post_status'    => array( 'publish' ),
			  'meta_key'       => 'post_type_' . CUSTOM_POST_TYPE_CLASSIFIED,
			  'meta_value'     => CUSTOM_POST_TYPE_CLASSIFIED,
			  'order'          => 'ASC',
			);
		} elseif ( isset( $_REQUEST['custom_reset'] ) && $_REQUEST['custom_reset'] != '' ) {
			/* Reset the listing custom fields - when click on reset ALL custom fields */
			$args = array(
			'post_type'    => 'custom_fields',
			  'posts_per_page' => -1,
			  'post_status'    => array( 'publish' ),
			  'order'          => 'ASC',
			);
		}
		$custom_field = new WP_Query( $args );
		if ( $custom_field ) :
			while ( $custom_field->have_posts() ) : $custom_field->the_post();
				wp_delete_post( get_the_ID(), true );
			endwhile;
		endif;
	}
	/*Finish the reset all custom fields */


	$exclude_post_type = apply_filters( 'reset_exclude_post_types',array() );
	$cus_pos_type = get_option( 'templatic_custom_post' );
	$post_type_arr = 'post,';
	$heading_post_type_arr = 'post,';
	if ( $cus_pos_type && count( $cus_pos_type ) > 0 ) {
		foreach ( $cus_pos_type as $key => $_cus_pos_type ) {
			if ( ! empty( $exclude_post_type ) ) {
				if ( ! in_array( $key,$exclude_post_type ) ) {
					$post_type_arr .= $key . ',';
				}
			} else {
				$post_type_arr .= $key . ',';
			}
			$heading_post_type_arr .= $key . ',';
		}
	}
	$post_type_arr = substr( $post_type_arr,0,-1 );
	$heading_post_type_arr = substr( $heading_post_type_arr,0,-1 );

	 /* Insert Locations Info heading into posts - Heading type - 4  */
	 $post_content = $wpdb->get_row( "SELECT post_title,ID FROM $wpdb->posts WHERE $wpdb->posts.post_name = 'locations_info' and $wpdb->posts.post_type = 'custom_fields'" );

	if ( count( $post_content ) == 0 ) {
		$my_post = array(
			 'post_title' => 'Locations & Map',
			 'post_content' => '',
			 'post_status' => 'publish',
			 'post_author' => 1,
			 'post_name' => 'locations_info',
			 'post_type' => 'custom_fields',
			);
		$post_meta = array(
			'post_type' => $post_type_arr,
			'post_type_classified' => $custom_post_type,
			'ctype' => 'heading_type',
			'htmlvar_name' => 'locations_info',
			'field_category' => 'all',
			'is_active' => '1',
			'is_submit_field' => '1',
			'is_require' => '0',
			'show_on_page' => 'both_side',
			'show_in_column' => '0',
			'show_on_listing' => '0',
			'is_edit' => 'true',
			'show_on_detail' => '1',
			'sort_order' => '4',
			'classified_sort_order' => '4',
			'is_search' => '0',
			'show_in_email'  => '1',
			'is_delete' => '0',
			);

		$post_id = wp_insert_post( $my_post );
		wp_set_post_terms( $post_id,'1','category',true );
		if ( is_plugin_active( 'sitepress-multilingual-cms/sitepress.php' ) ) {
			global $sitepress;
			$current_lang_code = ICL_LANGUAGE_CODE;
			$default_language = $sitepress->get_default_language();
			/* Insert wpml  icl_translations table*/
			$sitepress->set_element_language_details( $post_id, $el_type = 'post_custom_fields', $post_id, $current_lang_code, $default_language );
			if ( function_exists( 'wpml_insert_templ_post' ) ) {
				wpml_insert_templ_post( $post_id,'custom_fields' );
			}
		}
		/*wp_set_post_terms($post_id,'1','category',true);*/
		foreach ( $post_meta as $key => $_post_meta ) {
			add_post_meta( $post_id, $key, $_post_meta );
		}
		update_post_meta( $post_id, 'post_type_post','post' );
		update_post_meta( $post_id, 'taxonomy_type_category','category' );
		update_post_meta( $post_id, 'post_type',substr( $posttype,0,-1 ) );
		update_post_meta( $post_id, 'post_sort_order',8 );
	} else {
		   $post_type = get_post_meta( $post_content->ID, 'post_type',true );

		if ( ! strstr( $post_type,'classified' ) ) {
			update_post_meta( $post_content->ID, 'post_type',$post_type . ',classified' );
		}

			update_post_meta( $post_content->ID, 'post_type_classified','classified' );
			update_post_meta( $post_content->ID, 'post_type_classified','classified' );
			update_post_meta( $post_content->ID, 'taxonomy_type_classifiedscategory','classifiedscategory' );

		if ( get_post_meta( $post_content->ID,'classified_sort_order',true ) ) {
			update_post_meta( $post_content->ID, 'classified_sort_order',get_post_meta( $post_content->ID,'classified_sort_order',true ) );
		} else {
			update_post_meta( $post_content->ID, 'classified_sort_order',4 );
		}
			update_post_meta( $locations_info->ID, 'post_type',$posttype );
			update_post_meta( $locations_info->ID, 'post_type_post','post' );
			update_post_meta( $locations_info->ID, 'taxonomy_type_category','category' );
			update_post_meta( $locations_info->ID, 'post_sort_order',8 );
			update_post_meta( $locations_info->ID, 'post_type',substr( $posttype,0,-1 ) );
	}// End if().
	$post_city_id = $wpdb->get_row( "SELECT post_title,ID FROM $wpdb->posts WHERE $wpdb->posts.post_name = 'post_city_id' and $wpdb->posts.post_type = 'custom_fields'" );
	if ( count( $post_city_id ) == 0 ) {
		$my_post = array(
			 'post_title' => 'Multi City',
			 'post_content' => '',
			 'post_status' => 'publish',
			 'post_author' => 1,
			 'post_name' => 'post_city_id',
			 'post_type' => 'custom_fields',
			);
		$post_meta = array(
			'heading_type' => 'Locations & Map',
			'property_heading_type' => 'Locations & Map',
			'post_type' => $post_type_arr,
			'post_type_classified' => $custom_post_type,
			'ctype' => 'multicity',
			'htmlvar_name' => 'post_city_id',
			'field_category' => 'all',
			'sort_order' => '5',
			'classified_sort_order' => '5',
			'is_active' => '1',
			'is_submit_field' => '1',
			'is_require' => '0',
			'show_on_page' => 'both_side',
			'show_in_column' => '0',
			'show_on_listing' => '0',
			'is_edit' => 'true',
			'show_on_detail' => '0',
			'is_search' => '1',
			'show_in_email'  => '1',
			'is_delete' => '0',
			);
		$post_id = wp_insert_post( $my_post );
		wp_set_post_terms( $post_id,'1','category',true );
		/*wp_set_post_terms($post_id,'1','category',true);*/
		foreach ( $post_meta as $key => $_post_meta ) {
			add_post_meta( $post_id, $key, $_post_meta );
		}

		$post_types = get_option( 'templatic_custom_post' );
		$posttype = 'post,';
		foreach ( $post_types as $key => $val ) {
			$taxonomies = get_object_taxonomies( (object) array(
				'post_type' => $key,
				'public' => true,
				'_builtin' => true,
			) );
			$posttype .= $key . ',';
			update_post_meta( $post_id, 'post_type_' . $key,$key );
			if ( ! empty( $taxonomies ) ) {
				update_post_meta( $post_id, 'taxonomy_type_' . $taxonomies[0],$taxonomies[0] );
			}
			update_post_meta( $post_id, $key . '_sort_order',get_post_meta( $post_id, $key . '_sort_order',true ) );
		}
		update_post_meta( $post_id, 'post_type_post','post' );
		update_post_meta( $post_id, 'taxonomy_type_category','category' );
		update_post_meta( $post_id, 'post_type',substr( $posttype,0,-1 ) );
		update_post_meta( $post_id, 'show_on_detail','1' );

		update_post_meta( $post_id, 'post_type_property','classified' );
		$post_type = get_post_meta( $post_id, 'post_type',true );
		if ( ! strstr( $post_type,'classified' ) ) {
			update_post_meta( $post_id, 'post_type',$post_type . ',classified' );
		}
		update_post_meta( $post_id, 'taxonomy_type_classifiedscategory','classifiedscategory' );
		update_post_meta( $post_id, 'show_on_detail','1' );
		update_post_meta( $post_id, 'show_in_classified_search','1' );
		if ( is_plugin_active( 'sitepress-multilingual-cms/sitepress.php' ) ) {
			global $sitepress;
			$current_lang_code = ICL_LANGUAGE_CODE;
			$default_language = $sitepress->get_default_language();
			/* Insert wpml  icl_translations table*/
			$sitepress->set_element_language_details( $post_id, $el_type = 'post_custom_fields', $post_id, $current_lang_code, $default_language );
			if ( function_exists( 'wpml_insert_templ_post' ) ) {
				wpml_insert_templ_post( $post_id,'custom_fields' );
			}
		}
	} else {

		 //update_post_meta($post_city_id->ID, 'show_on_detail','1' );

		 $post_type = get_post_meta( $post_city_id->ID, 'post_type',true );

		if ( ! strstr( $post_type,'classified' ) ) {
			update_post_meta( $post_city_id->ID, 'post_type',$post_type . ',classified' );
		}

			update_post_meta( $post_city_id->ID, 'post_type_classified','classified' );
			update_post_meta( $post_city_id->ID, 'taxonomy_type_classifiedscategory','classifiedscategory' );
			//update_post_meta($post_city_id->ID, 'show_on_detail','1' );
			update_post_meta( $post_city_id->ID, 'show_in_classified_search','1' );
		if ( get_post_meta( $post_city_id->ID,'classified_sort_order',true ) ) {
			update_post_meta( $post_city_id->ID, 'classified_sort_order',get_post_meta( $post_city_id->ID,'classified_sort_order',true ) );
		} else {
			update_post_meta( $post_city_id->ID, 'classified_sort_order',5 );
		}
			//update_post_meta($post_city_id->ID, 'show_on_detail','1' );
		if ( get_post_meta( $post_city_id->ID,'classified_heading_type',true ) ) {
			update_post_meta( $post_city_id->ID, 'classified_heading_type',get_post_meta( $post_city_id->ID,'classified_heading_type',true ) );
		} else {
			update_post_meta( $post_city_id->ID, 'classified_heading_type','Locations & Map' );
		}
	}// End if().

	$post_content = $wpdb->get_row( "SELECT post_title,ID FROM $wpdb->posts WHERE $wpdb->posts.post_name = 'address' and $wpdb->posts.post_type = 'custom_fields'" );
	if ( count( $post_content ) == 0 ) {
		$my_post = array(
			 'post_title' => 'Location',
			 'post_content' => '',
			 'post_status' => 'publish',
			 'post_author' => 1,
			 'post_name' => 'address',
			 'post_type' => 'custom_fields',
			);
		$post_meta = array(
			'heading_type' => 'Locations & Map',
			'classified_heading_type' => 'Locations & Map',
			'post_type' => $post_type_arr,
			'post_type_classified' => $custom_post_type,
			'ctype' => 'geo_map',
			'htmlvar_name' => 'address',
			'field_category' => 'all',
			'is_require' => '1',
			'sort_order' => '6',
			'classified_sort_order' => '6',
			'is_submit_field' => '1',
			'is_active' => '1',
			'show_on_page' => 'both_side',
			'show_in_column' => '0',
			'show_on_listing' => '1',
			'is_edit' => 'true',
			'show_on_detail' => '1',
			'is_delete' => '0',
			'show_on_success' => '1',
			'is_search' => '0',
			'show_in_email'  => '1',
			'field_require_desc' => 'Please Enter Address',
			'validation_type' => 'require',
			);
		$post_id = wp_insert_post( $my_post );
		wp_set_post_terms( $post_id,'1','category',true );
		if ( is_plugin_active( 'sitepress-multilingual-cms/sitepress.php' ) ) {
			global $sitepress;
			$current_lang_code = ICL_LANGUAGE_CODE;
			$default_language = $sitepress->get_default_language();
			/* Insert wpml  icl_translations table*/
			$sitepress->set_element_language_details( $post_id, $el_type = 'post_custom_fields', $post_id, $current_lang_code, $default_language );
			if ( function_exists( 'wpml_insert_templ_post' ) ) {
				wpml_insert_templ_post( $post_id,'custom_fields' );
			}
		}
		/*wp_set_post_terms($post_id,'1','category',true);*/
		foreach ( $post_meta as $key => $_post_meta ) {
			add_post_meta( $post_id, $key, $_post_meta );
		}
	} else {
		$post_type = get_post_meta( $post_content->ID, 'post_type',true );
		if ( ! strstr( $post_type,'classified' ) ) {
			update_post_meta( $post_content->ID, 'post_type',$post_type . ',classified' );
		}

		  update_post_meta( $post_content->ID, 'post_type_classified','classified' );
		  update_post_meta( $post_content->ID, 'taxonomy_type_classifiedscategory','classifiedscategory' );

		if ( get_post_meta( $post_content->ID,'classified_sort_order',true ) ) {
			update_post_meta( $post_content->ID, 'classified_sort_order',get_post_meta( $post_content->ID,'classified_sort_order',true ) );
		} else {
			update_post_meta( $post_content->ID, 'classified_sort_order',6 );
		}
		if ( get_post_meta( $post_content->ID,'classified_heading_type',true ) ) {
			update_post_meta( $post_content->ID, 'classified_heading_type',get_post_meta( $post_content->ID,'classified_heading_type',true ) );
		} else {
			update_post_meta( $post_content->ID, 'classified_heading_type','Locations & Map' );
		}
	}// End if().

	 $post_content = $wpdb->get_row( "SELECT post_title,ID FROM $wpdb->posts WHERE $wpdb->posts.post_name = 'zip_code' and $wpdb->posts.post_type = 'custom_fields'" );
	if ( count( $post_content ) == 0 ) {
		$my_post = array(
		   'post_title' => 'Zip Code',
		   'post_content' => '',
		   'post_status' => 'publish',
		   'post_author' => 1,
		   'post_name' => 'zip_code',
		   'post_type' => 'custom_fields',
		  );
		$post_meta = array(
		  'heading_type' => 'Locations & Map',
		  'classified_heading_type' => 'Locations & Map',
		  'post_type' => $post_type_arr,
		  'post_type_classified' => $custom_post_type,
		  'ctype' => 'text',
		  'htmlvar_name' => 'zip_code',
		  'field_category' => 'all',
		  'is_require' => '1',
		  'sort_order' => '6',
		  'classified_sort_order' => '6',
		  'is_submit_field' => '1',
		  'is_active' => '1',
		  'show_on_page' => 'both_side',
		  'show_in_column' => '0',
		  'show_on_listing' => '0',
		  'is_edit' => 'true',
		  'show_on_detail' => '1',
		  'is_delete' => '0',
		  'show_on_success' => '1',
		  'is_search' => '0',
		  'show_in_email'  => '1',
		  'field_require_desc' => 'Please Enter Zip Code',
		  'validation_type' => 'require',
		  );
		$post_id = wp_insert_post( $my_post );
		wp_set_post_terms( $post_id,'1','category',true );
		if ( is_plugin_active( 'sitepress-multilingual-cms/sitepress.php' ) ) {
			global $sitepress;
			$current_lang_code = ICL_LANGUAGE_CODE;
			$default_language = $sitepress->get_default_language();
			/* Insert wpml  icl_translations table*/
			$sitepress->set_element_language_details( $post_id, $el_type = 'post_custom_fields', $post_id, $current_lang_code, $default_language );
			if ( function_exists( 'wpml_insert_templ_post' ) ) {
				wpml_insert_templ_post( $post_id,'custom_fields' );
			}
		}
		/*wp_set_post_terms($post_id,'1','category',true);*/
		foreach ( $post_meta as $key => $_post_meta ) {
			add_post_meta( $post_id, $key, $_post_meta );
		}
	} else {
		$post_type = get_post_meta( $post_content->ID, 'post_type',true );
		if ( ! strstr( $post_type,'classified' ) ) {
			update_post_meta( $post_content->ID, 'post_type',$post_type . ',classified' );
		}

		  update_post_meta( $post_content->ID, 'post_type_classified','classified' );
		  update_post_meta( $post_content->ID, 'taxonomy_type_classifiedscategory','classifiedscategory' );

		if ( get_post_meta( $post_content->ID,'classified_sort_order',true ) ) {
			update_post_meta( $post_content->ID, 'classified_sort_order',get_post_meta( $post_content->ID,'classified_sort_order',true ) );
		} else {
			update_post_meta( $post_content->ID, 'classified_sort_order',7 );
		}
		if ( get_post_meta( $post_content->ID,'classified_heading_type',true ) ) {
			update_post_meta( $post_content->ID, 'classified_heading_type',get_post_meta( $post_content->ID,'classified_heading_type',true ) );
		} else {
			update_post_meta( $post_content->ID, 'classified_heading_type','Locations & Map' );
		}
	}// End if().


	/* Insert Post Google Map View into posts */
	$post_content = $wpdb->get_row( "SELECT post_title,ID FROM $wpdb->posts WHERE $wpdb->posts.post_name = 'map_view' and $wpdb->posts.post_type = 'custom_fields'" );
	if ( count( $post_content ) == 0 ) {
		$my_post = array(
			 'post_title' => 'Google Map View',
			 'post_content' => '',
			 'post_status' => 'publish',
			 'post_author' => 1,
			 'post_name' => 'map_view',
			 'post_type' => 'custom_fields',
			);
		$post_meta = array(
			'heading_type' => 'Locations & Map',
			'classified_heading_type' => 'Locations & Map',
			'post_type' => $post_type_arr,
			'post_type_classified' => $custom_post_type,
			'ctype' => 'radio',
			'htmlvar_name' => 'map_view',
			'field_category' => 'all',
			'sort_order' => '8',
			'classified_sort_order' => '8',
			'is_submit_field' => '1',
			'is_active' => '1',
			'is_require' => '1',
			'show_on_page' => 'both_side',
			'show_in_column' => '0',
			'show_on_listing' => '0',
			'is_edit' => 'true',
			'show_on_detail' => '1',
			'is_delete' => '0',
			'is_search' => '0',
			'show_in_email'  => '1',
			'show_on_success' => '0',
			'option_title' => 'Road Map,Terrain Map,Satellite Map,Street View',
			'option_values' => 'Road Map,Terrain Map,Satellite Map,Street Map',

			);
		$post_id = wp_insert_post( $my_post );
		wp_set_post_terms( $post_id,'1','category',true );
		if ( is_plugin_active( 'sitepress-multilingual-cms/sitepress.php' ) ) {
			global $sitepress;
			$current_lang_code = ICL_LANGUAGE_CODE;
			$default_language = $sitepress->get_default_language();
			/* Insert wpml  icl_translations table*/
			$sitepress->set_element_language_details( $post_id, $el_type = 'post_custom_fields', $post_id, $current_lang_code, $default_language );
			if ( function_exists( 'wpml_insert_templ_post' ) ) {
				wpml_insert_templ_post( $post_id,'custom_fields' );
			}
		}
		/*	wp_set_post_terms($post_id,'1','category',true);*/
		foreach ( $post_meta as $key => $_post_meta ) {
			add_post_meta( $post_id, $key, $_post_meta );
		}
	} else {
		$post_type = get_post_meta( $post_content->ID, 'post_type',true );
		if ( ! strstr( $post_type,'classified' ) ) {
			update_post_meta( $post_content->ID, 'post_type',$post_type . ',classified' );
		}

			update_post_meta( $post_content->ID, 'post_type_classified','classified' );
			update_post_meta( $post_content->ID, 'taxonomy_type_classifiedscategory','classifiedscategory' );

		if ( get_post_meta( $post_content->ID,'classified_sort_order',true ) ) {
			update_post_meta( $post_content->ID, 'classified_sort_order',get_post_meta( $post_content->ID,'classified_sort_order',true ) );
		} else {
			update_post_meta( $post_content->ID, 'classified_sort_order',9 );
		}
		if ( get_post_meta( $post_content->ID,'classified_heading_type',true ) ) {
			update_post_meta( $post_content->ID, 'classified_heading_type',get_post_meta( $post_content->ID,'classified_heading_type',true ) );
		} else {
			update_post_meta( $post_content->ID, 'classified_heading_type','Locations & Map' );
		}
	}// End if().

	$classified_info = $wpdb->get_row( "SELECT post_title,ID FROM $wpdb->posts WHERE $wpdb->posts.post_name = 'classified_info' and $wpdb->posts.post_type = 'custom_fields'" );

	if ( count( $classified_info ) == 0 ) {
		$my_post = array(
			 'post_title' => 'Classified Information',
			 'post_content' => '',
			 'post_status' => 'publish',
			 'post_author' => 1,
			 'post_name' => 'classified_info',
			 'post_type' => 'custom_fields',
			);
		$post_meta = array(
			'post_type' => $custom_post_type,
			'post_type_classified' => $custom_post_type,
			'ctype' => 'heading_type',
			'htmlvar_name' => 'classified_info',
			'field_category' => 'all',
			'sort_order' => '9',
			'classified_sort_order' => '9',
			'is_active' => '1',
			'is_submit_field' => '1',
			'is_require' => '0',
			'show_on_page' => 'both_side',
			'show_in_column' => '0',
			'show_on_listing' => '0',
			'is_edit' => 'true',
			'show_on_detail' => '1',
			'is_search' => '0',
			'show_in_email'  => '1',
			'is_delete' => '0',
			);
		wp_set_post_terms( $post_id,'1','category',true );
		$post_id = wp_insert_post( $my_post );

		if ( is_plugin_active( 'sitepress-multilingual-cms/sitepress.php' ) ) {
			global $sitepress;
			$current_lang_code = ICL_LANGUAGE_CODE;
			$default_language = $sitepress->get_default_language();
			/* Insert wpml  icl_translations table*/
			$sitepress->set_element_language_details( $post_id, $el_type = 'post_custom_fields',$post_id, $current_lang_code, $default_language );
			if ( function_exists( 'wpml_insert_templ_post' ) ) {
				wpml_insert_templ_post( $post_id,'custom_fields' );
			}
		}

		/*wp_set_post_terms($post_id,'1','category',true);*/
		foreach ( $post_meta as $key => $_post_meta ) {
			add_post_meta( $post_id, $key, $_post_meta );
		}
	} else {
		$post_type = get_post_meta( $classified_info->ID, 'post_type',true );
		if ( ! strstr( $post_type,'classified' ) ) {
			update_post_meta( $classified_info->ID, 'post_type',$post_type . ',classified' );
		}

			update_post_meta( $classified_info->ID, 'post_type_classified','classified' );
			update_post_meta( $classified_info->ID, 'taxonomy_type_classifiedscategory','classifiedscategory' );
			update_post_meta( $classified_info->ID, 'is_submit_field',1 );
		if ( get_post_meta( $classified_info->ID,'classified_sort_order',true ) ) {
			update_post_meta( $classified_info->ID, 'classified_sort_order',get_post_meta( $classified_info->ID,'classified_sort_order',true ) );
		} else {
			update_post_meta( $classified_info->ID, 'classified_sort_order',9 );
		}
	}// End if().



	$post_content = $wpdb->get_row( "SELECT post_title,ID FROM $wpdb->posts WHERE $wpdb->posts.post_name = 'ad_id' and $wpdb->posts.post_type = 'custom_fields'" );
	if ( count( $post_content ) == 0 ) {
		$my_post = array(
		   'post_title' => 'Ad ID',
		   'post_content' => '',
		   'post_status' => 'publish',
		   'post_author' => 1,
		   'post_name' => 'ad_id',
		   'post_type' => 'custom_fields',
		  );
		$post_meta = array(
		  'heading_type' => 'Classified Information',
		  'classified_heading_type' => 'Classified Information',
		  'post_type' => $custom_post_type,
		  'post_type_classified' => $custom_post_type,
		  'ctype' => 'text',
		  'htmlvar_name' => 'ad_id',
		  'field_category' => 'all',
		  'sort_order' => '10',
		  'classified_sort_order' => '10',
		  'is_submit_field' => '1',
		  'is_active' => '1',
		  'is_require' => '0',
		  'show_on_page' => 'both_side',
		  'show_in_column' => '0',
		  'show_on_listing' => '0',
		  'is_edit' => 'true',
		  'show_on_detail' => '1',
		  'is_delete' => '0',
		  'is_search' => '0',
		  'show_in_email'  => '0',
		  'show_on_success' => '0',
		  'field_require_desc' => '',
		  'validation_type' => '',
		  );
		$post_id = wp_insert_post( $my_post );
		wp_set_post_terms( $post_id,'1','category',true );
		if ( is_plugin_active( 'sitepress-multilingual-cms/sitepress.php' ) ) {
			global $sitepress;
			$current_lang_code = ICL_LANGUAGE_CODE;
			$default_language = $sitepress->get_default_language();
			/* Insert wpml  icl_translations table*/
			$sitepress->set_element_language_details( $post_id, $el_type = 'post_custom_fields', $post_id, $current_lang_code, $default_language );
			if ( function_exists( 'wpml_insert_templ_post' ) ) {
				wpml_insert_templ_post( $post_id,'custom_fields' );
			}
		}
		/*wp_set_post_terms($post_id,'1','category',true);*/
		foreach ( $post_meta as $key => $_post_meta ) {
			add_post_meta( $post_id, $key, $_post_meta );
		}
	} else {
		$post_type = get_post_meta( $post_content->ID, 'post_type',true );
		if ( ! strstr( $post_type,'classified' ) ) {
			update_post_meta( $post_content->ID, 'post_type',$post_type . ',classified' );
		}

		  update_post_meta( $post_content->ID, 'post_type_classified','classified' );
		  update_post_meta( $post_content->ID, 'taxonomy_type_classifiedscategory','classifiedscategory' );

		if ( get_post_meta( $post_content->ID,'classified_sort_order',true ) ) {
			update_post_meta( $post_content->ID, 'classified_sort_order',get_post_meta( $post_content->ID,'classified_sort_order',true ) );
		} else {
			update_post_meta( $post_content->ID, 'classified_sort_order',7 );
		}
		if ( get_post_meta( $post_content->ID,'classified_heading_type',true ) ) {
			update_post_meta( $post_content->ID, 'classified_heading_type',get_post_meta( $post_content->ID,'classified_heading_type',true ) );
		} else {
			update_post_meta( $post_content->ID, 'classified_heading_type','Locations & Map' );
		}
	}// End if().


	/* Insert Post Price type into posts */
	$post_content = $wpdb->get_row( "SELECT post_title,ID FROM $wpdb->posts WHERE $wpdb->posts.post_name = 'price_type' and $wpdb->posts.post_type = 'custom_fields'" );
	if ( count( $post_content ) == 0 ) {
		$my_post = array(
			 'post_title' => 'Price Type',
			 'post_content' => '',
			 'post_status' => 'publish',
			 'post_author' => 1,
			 'post_name' => 'price_type',
			 'post_type' => 'custom_fields',
			);
		$post_meta = array(
			'heading_type' => 'Classified Information',
			'classified_heading_type' => 'Classified Information',
			'post_type' => $custom_post_type,
			'post_type_classified' => $custom_post_type,
			'ctype' => 'radio',
			'htmlvar_name' => 'price_type',
			'field_category' => 'all',
			'sort_order' => '10',
			'classified_sort_order' => '10',
			'is_submit_field' => '1',
			'is_active' => '1',
			'is_require' => '1',
			'show_on_page' => 'both_side',
			'show_in_column' => '0',
			'show_on_listing' => '0',
			'is_edit' => 'true',
			'show_on_detail' => '1',
			'is_delete' => '0',
			'is_search' => '0',
			'show_in_email'  => '1',
			'show_on_success' => '1',
			'option_title' => 'Fixed Price,Negotiable,Exchange Donate,Free',
			'option_values' => 'fixed,negotiable,exchange,free',
			'field_require_desc' => 'Please select the price type.',
			'validation_type' => 'require',
			);
		$post_id = wp_insert_post( $my_post );
		wp_set_post_terms( $post_id,'1','category',true );
		if ( is_plugin_active( 'sitepress-multilingual-cms/sitepress.php' ) ) {
			global $sitepress;
			$current_lang_code = ICL_LANGUAGE_CODE;
			$default_language = $sitepress->get_default_language();
			/* Insert wpml  icl_translations table*/
			$sitepress->set_element_language_details( $post_id, $el_type = 'post_custom_fields', $post_id, $current_lang_code, $default_language );
			if ( function_exists( 'wpml_insert_templ_post' ) ) {
				wpml_insert_templ_post( $post_id,'custom_fields' );
			}
		}
		/*	wp_set_post_terms($post_id,'1','category',true);*/
		foreach ( $post_meta as $key => $_post_meta ) {
			add_post_meta( $post_id, $key, $_post_meta );
		}
	} else {
		$post_type = get_post_meta( $post_content->ID, 'post_type',true );
		if ( ! strstr( $post_type,'classified' ) ) {
			update_post_meta( $post_content->ID, 'post_type',$post_type . ',classified' );
		}

			update_post_meta( $post_content->ID, 'post_type_classified','classified' );
			update_post_meta( $post_content->ID, 'taxonomy_type_classifiedscategory','classifiedscategory' );

		if ( get_post_meta( $classified_info->ID,'classified_sort_order',true ) ) {
			update_post_meta( $classified_info->ID, 'classified_sort_order',get_post_meta( $classified_info->ID,'classified_sort_order',true ) );
		} else {
			update_post_meta( $classified_info->ID, 'classified_sort_order',10 );
		}
		if ( get_post_meta( $post_content->ID,'classified_heading_type',true ) ) {
			update_post_meta( $post_content->ID, 'classified_heading_type',get_post_meta( $post_content->ID,'classified_heading_type',true ) );
		} else {
			update_post_meta( $post_content->ID, 'classified_heading_type','Classified Information' );
		}
	}// End if().

	/* Insert Price field into posts */
	$post_content = $wpdb->get_row( "SELECT post_title,ID FROM $wpdb->posts WHERE $wpdb->posts.post_name = 'price' and $wpdb->posts.post_type = 'custom_fields'" );
	if ( count( $post_content ) == 0 ) {
		$my_post = array(
			 'post_title' => 'Price (IN ' . get_option( 'currency_code' ) . ' ' . get_option( 'currency_symbol' ) . ')',
			 'post_content' => '',
			 'post_status' => 'publish',
			 'post_author' => 1,
			 'post_name' => 'price',
			 'post_type' => 'custom_fields',
			);
		$post_meta = array(
			'heading_type' => 'Classified Information',
			'classified_heading_type' => 'Classified Information',
			'post_type' => $custom_post_type,
			'post_type_classified' => $custom_post_type,
			'ctype' => 'text',
			'htmlvar_name' => 'price',
			'field_category' => 'all',
			'sort_order' => '11',
			'classified_sort_order' => '11',
			'is_submit_field' => '1',
			'is_active' => '1',
			'is_require' => '1',
			'show_on_page' => 'both_side',
			'show_in_column' => '0',
			'show_on_listing' => '1',
			'is_edit' => 'true',
			'show_on_detail' => '1',
			'is_delete' => '0',
			'is_search' => '1',
			'show_in_email'  => '1',
			'show_on_success' => '0',
			'field_require_desc' => 'Values must be all numbers.',
			'validation_type' => 'digit',
			);
		$post_id = wp_insert_post( $my_post );
		wp_set_post_terms( $post_id,'1','category',true );
		if ( is_plugin_active( 'sitepress-multilingual-cms/sitepress.php' ) ) {
			global $sitepress;
			$current_lang_code = ICL_LANGUAGE_CODE;
			$default_language = $sitepress->get_default_language();
			/* Insert wpml  icl_translations table*/
			$sitepress->set_element_language_details( $post_id, $el_type = 'post_custom_fields', $post_id, $current_lang_code, $default_language );
			if ( function_exists( 'wpml_insert_templ_post' ) ) {
				wpml_insert_templ_post( $post_id,'custom_fields' );
			}
		}

		foreach ( $post_meta as $key => $_post_meta ) {
			add_post_meta( $post_id, $key, $_post_meta );
		}
	} else {
		$post_type = get_post_meta( $post_content->ID, 'post_type',true );
		update_post_meta( $post_content->ID, 'is_search','1' );
		if ( ! strstr( $post_type,'classified' ) ) {
			update_post_meta( $post_content->ID, 'post_type',$post_type . ',classified' );
		}

		 update_post_meta( $post_content->ID, 'post_type_classified','classified' );
		 update_post_meta( $post_content->ID, 'taxonomy_type_classifiedscategory','classifiedscategory' );


		if ( get_post_meta( $classified_info->ID,'classified_sort_order',true ) ) {
			update_post_meta( $classified_info->ID, 'classified_sort_order',get_post_meta( $classified_info->ID,'classified_sort_order',true ) );
		} else {
			update_post_meta( $classified_info->ID, 'classified_sort_order',11 );
		}
		if ( get_post_meta( $post_content->ID,'classified_heading_type',true ) ) {
			update_post_meta( $post_content->ID, 'classified_heading_type',get_post_meta( $post_content->ID,'classified_heading_type',true ) );
		} else {
			update_post_meta( $post_content->ID, 'classified_heading_type','Classified Information' );
		}
	}// End if().

	/* Add/Edit classified tags */
	$post_content = $wpdb->get_row( "SELECT post_title,ID FROM $wpdb->posts WHERE $wpdb->posts.post_name = 'classified_tag' and $wpdb->posts.post_type = 'custom_fields'" );
	if ( count( $post_content ) == 0 ) {
		$my_post = array(
			'post_title' => 'Classified Status',
			'post_content' => '',
			'post_status' => 'publish',
			'post_author' => 1,
			'post_name' => 'classified_tag',
			'post_type' => 'custom_fields',
		   );
		$post_meta = array(
		   'heading_type' => 'Classified Information',
		   'classified_heading_type' => 'Classified Information',
		   'post_type' => $custom_post_type,
		   'post_type_classified' => $custom_post_type,
		   'ctype' => 'select',
		   'htmlvar_name' => 'classified_tag',
		   'field_category' => 'all',
		   'sort_order' => '12',
		   'classified_sort_order' => '12',
		   'is_submit_field' => '1',
		   'is_active' => '1',
		   'is_require' => '0',
		   'show_on_page' => 'both_side',
		   'show_in_column' => '0',
		   'show_on_listing' => '1',
		   'option_title' => 'Sold,O.N.O,O.V.N.O,No Offers,Part Exchange,Private Sale,Trade',
		   'option_values' => 'Sold,O.N.O,O.V.N.O,no_offer,part_exchange,private_sale,trade',
		   'is_edit' => 'true',
		   'show_on_detail' => '1',
		   'is_delete' => '0',
		   'is_search' => '0',
		   'show_in_email'  => '1',
		   'show_on_success' => '1',
		   );
		$post_id = wp_insert_post( $my_post );
		wp_set_post_terms( $post_id,'1','category',true );
		if ( is_plugin_active( 'sitepress-multilingual-cms/sitepress.php' ) ) {
			global $sitepress;
			$current_lang_code = ICL_LANGUAGE_CODE;
			$default_language = $sitepress->get_default_language();
			/* Insert wpm l  icl_translations table*/
			$sitepress->set_element_language_details( $post_id, $el_type = 'post_custom_fields', $post_id, $current_lang_code, $default_language );
			if ( function_exists( 'wpml_insert_templ_post' ) ) {
				wpml_insert_templ_post( $post_id,'custom_fields' );
			}
		}
		/*wp_set_post_terms($post_id,'1','category',true);*/
		foreach ( $post_meta as $key => $_post_meta ) {
			add_post_meta( $post_id, $key, $_post_meta );
		}
	} else {
		$post_type = get_post_meta( $post_content->ID, 'post_type',true );
		update_post_meta( $post_content->ID, 'is_search','1' );
		if ( ! strstr( $post_type,'classified' ) ) {
			update_post_meta( $post_content->ID, 'post_type',$post_type . ',classified' );
		}

			update_post_meta( $post_content->ID, 'post_type_classified','classified' );
			update_post_meta( $post_content->ID, 'taxonomy_type_classifiedscategory','classifiedscategory' );


		if ( get_post_meta( $classified_info->ID,'classified_sort_order',true ) ) {
			update_post_meta( $classified_info->ID, 'classified_sort_order',get_post_meta( $classified_info->ID,'classified_sort_order',true ) );
		} else {
			update_post_meta( $classified_info->ID, 'classified_sort_order',12 );
		}
		if ( get_post_meta( $post_content->ID,'classified_heading_type',true ) ) {
			update_post_meta( $post_content->ID, 'classified_heading_type',get_post_meta( $post_content->ID,'classified_heading_type',true ) );
		} else {
			update_post_meta( $post_content->ID, 'classified_heading_type','Classified Information' );
		}
	}// End if().

	/* Insert Post Contact Info heading into posts */
	$field_label = $wpdb->get_row( "SELECT post_title,ID FROM $wpdb->posts WHERE $wpdb->posts.post_name = 'field_label' and $wpdb->posts.post_type = 'custom_fields'" );

	if ( count( $field_label ) == 0 ) {
		$my_post = array(
		 'post_title' => 'Label of Field',
		 'post_content' => '',
		 'post_status' => 'publish',
		 'post_author' => 1,
		 'post_name' => 'field_label',
		 'post_type' => 'custom_fields',
		);
		$post_meta = array(
		'post_type' => $post_type_arr,
		'post_type_classified' => $custom_post_type,
		'ctype' => 'heading_type',
		'htmlvar_name' => 'field_label',
		'field_category' => 'all',
		'sort_order' => '19',
		'classified_sort_order' => '19',
		'is_active' => '1',
		'is_submit_field' => 1,
		'is_require' => '0',
		'show_on_page' => 'both_side',
		'show_in_column' => '0',
		'show_on_listing' => '0',
		'is_edit' => 'true',
		'show_on_detail' => '1',
		'is_search' => '0',
		'show_in_email'  => '1',
		'is_delete' => '0',
		);
		wp_set_post_terms( $post_id,'1','category',true );
		$post_id = wp_insert_post( $my_post );

		if ( is_plugin_active( 'sitepress-multilingual-cms/sitepress.php' ) ) {
			global $sitepress;
			$current_lang_code = ICL_LANGUAGE_CODE;
			$default_language = $sitepress->get_default_language();
			/* Insert wpml  icl_translations table*/
			$sitepress->set_element_language_details( $post_id, $el_type = 'post_custom_fields',$post_id, $current_lang_code, $default_language );
			if ( function_exists( 'wpml_insert_templ_post' ) ) {
				wpml_insert_templ_post( $post_id,'custom_fields' );
			}
		}

		/*wp_set_post_terms($post_id,'1','category',true);*/
		foreach ( $post_meta as $key => $_post_meta ) {
			add_post_meta( $post_id, $key, $_post_meta );
		}
	} else {
		$post_type = get_post_meta( $field_label->ID, 'post_type',true );
		if ( ! strstr( $post_type,'classified' ) ) {
			update_post_meta( $field_label->ID, 'post_type',$post_type . ',classified' );
		}

		update_post_meta( $field_label->ID, 'post_type_classified','classified' );
		update_post_meta( $field_label->ID, 'taxonomy_type_classifiedscategory','classifiedscategory' );
		update_post_meta( $field_label->ID, 'is_submit_field',1 );

		if ( get_post_meta( $field_label->ID,'classified_sort_order',true ) ) {
			update_post_meta( $field_label->ID, 'classified_sort_order',get_post_meta( $field_label->ID,'classified_sort_order',true ) );
		} else {
			update_post_meta( $field_label->ID, 'classified_sort_order',19 );
		}
	}// End if().

	/* Insert Contact Info heading into posts */
	$post_content = $wpdb->get_row( "SELECT post_title,ID FROM $wpdb->posts WHERE $wpdb->posts.post_name = 'seller_contact_info' and $wpdb->posts.post_type = 'custom_fields'" );

	if ( count( $post_content ) == 0 ) {
		$my_post = array(
			 'post_title' => 'Seller Contact Information',
			 'post_content' => '',
			 'post_status' => 'publish',
			 'post_author' => 1,
			 'post_name' => 'seller_contact_info',
			 'post_type' => 'custom_fields',
			);
		$post_meta = array(
			'post_type' => $custom_post_type,
			'post_type_classified' => $custom_post_type,
			'ctype' => 'heading_type',
			'htmlvar_name' => 'seller_contact_info',
			'field_category' => 'all',
			'sort_order' => '15',
			'classified_sort_order' => '15',
			'is_submit_field' => '1',
			'is_active' => '1',
			'is_require' => '0',
			'show_on_page' => 'both_side',
			'show_in_column' => '0',
			'show_on_listing' => '0',
			'is_edit' => 'true',
			'show_on_detail' => '1',
			'is_search' => '0',
			'show_in_email'  => '1',
			'is_delete' => '0',
			);

		$post_id = wp_insert_post( $my_post );
		wp_set_post_terms( $post_id,'1','category',true );
		if ( is_plugin_active( 'sitepress-multilingual-cms/sitepress.php' ) ) {
			global $sitepress;
			$current_lang_code = ICL_LANGUAGE_CODE;
			$default_language = $sitepress->get_default_language();
			/* Insert wpml  icl_translations table*/
			$sitepress->set_element_language_details( $post_id, $el_type = 'post_custom_fields', $post_id, $current_lang_code, $default_language );
			if ( function_exists( 'wpml_insert_templ_post' ) ) {
				wpml_insert_templ_post( $post_id,'custom_fields' );
			}
		}
		/*wp_set_post_terms($post_id,'1','category',true);*/
		foreach ( $post_meta as $key => $_post_meta ) {
			add_post_meta( $post_id, $key, $_post_meta );
		}
	} else {
		  $post_type = get_post_meta( $post_content->ID, 'post_type',true );
		if ( ! strstr( $post_type,'classified' ) ) {
			update_post_meta( $post_content->ID, 'post_type',$post_type . ',classified' );
		}

		  update_post_meta( $post_content->ID, 'post_type_classified','classified' );
		  update_post_meta( $post_content->ID, 'taxonomy_type_classifiedscategory','classifiedscategory' );


		if ( get_post_meta( $classified_info->ID,'classified_sort_order',true ) ) {
			update_post_meta( $classified_info->ID, 'classified_sort_order',get_post_meta( $classified_info->ID,'classified_sort_order',true ) );
		} else {
			update_post_meta( $classified_info->ID, 'classified_sort_order',15 );
		}
	}// End if().

	 /* Insert Post heading into posts */

	 /* Insert Consider this classified as classified Zip */
	 $post_content = $wpdb->get_row( "SELECT post_title,ID FROM $wpdb->posts WHERE $wpdb->posts.post_name = 'owner_name' and $wpdb->posts.post_type = 'custom_fields'" );
	if ( count( $post_content ) == 0 ) {
		$my_post = array(
		   'post_title' => 'Owner name',
		   'post_content' => '',
		   'post_status' => 'publish',
		   'post_author' => 1,
		   'post_name' => 'owner_name',
		   'post_type' => 'custom_fields',
		  );
		$post_meta = array(
		  'heading_type' => 'Seller Contact Information',
		  'classified_heading_type' => 'Seller Contact Information',
		  'post_type' => $custom_post_type,
		  'post_type_classified' => $custom_post_type,
		  'ctype' => 'text',
		  'htmlvar_name' => 'owner_name',
		  'field_category' => 'all',
		  'sort_order' => '16',
		  'classified_sort_order' => '16',
		  'is_submit_field' => '1',
		  'is_active' => '1',
		  'is_require' => '1',
		  'show_on_page' => 'both_side',
		  'show_in_column' => '0',
		  'show_on_listing' => '1',
		  'is_edit' => 'true',
		  'is_search' => '0',
		  'show_on_detail' => '1',
		  'is_delete' => '0',
		  'show_in_email'  => '1',
		  'field_require_desc' => '',
		  'validation_type' => 'require',
		  );
		$post_id = wp_insert_post( $my_post );
		wp_set_post_terms( $post_id,'1','category',true );
		if ( is_plugin_active( 'sitepress-multilingual-cms/sitepress.php' ) ) {
			global $sitepress;
			$current_lang_code = ICL_LANGUAGE_CODE;
			$default_language = $sitepress->get_default_language();
			/* Insert wpml  icl_translations table*/
			$sitepress->set_element_language_details( $post_id, $el_type = 'post_custom_fields', $post_id, $current_lang_code, $default_language );
			if ( function_exists( 'wpml_insert_templ_post' ) ) {
				wpml_insert_templ_post( $post_id,'custom_fields' );
			}
		}
		/*wp_set_post_terms($post_id,'1','category',true);*/
		foreach ( $post_meta as $key => $_post_meta ) {
			add_post_meta( $post_id, $key, $_post_meta );
		}
	} else {
		$post_type = get_post_meta( $post_content->ID, 'post_type',true );
		if ( ! strstr( $post_type,'classified' ) ) {
			update_post_meta( $post_content->ID, 'post_type',$post_type . ',classified' );
		}

		   update_post_meta( $post_content->ID, 'post_type_classified','classified' );
		   update_post_meta( $post_content->ID, 'taxonomy_type_classifiedscategory','classifiedscategory' );


		if ( get_post_meta( $classified_info->ID,'classified_sort_order',true ) ) {
			update_post_meta( $classified_info->ID, 'classified_sort_order',get_post_meta( $classified_info->ID,'classified_sort_order',true ) );
		} else {
			update_post_meta( $classified_info->ID, 'classified_sort_order',16 );
		}
		if ( get_post_meta( $post_content->ID,'classified_heading_type',true ) ) {
			update_post_meta( $post_content->ID, 'classified_heading_type',get_post_meta( $post_content->ID,'classified_heading_type',true ) );
		} else {
			update_post_meta( $post_content->ID, 'classified_heading_type','Label of Field' );
		}
	}// End if().

	/* Insert Consider this classified as classified Zip */
	$post_content = $wpdb->get_row( "SELECT post_title,ID FROM $wpdb->posts WHERE $wpdb->posts.post_name = 'web_site' and $wpdb->posts.post_type = 'custom_fields'" );
	if ( count( $post_content ) == 0 ) {
		$my_post = array(
			 'post_title' => 'Website URL',
			 'post_content' => '',
			 'post_status' => 'publish',
			 'post_author' => 1,
			 'post_name' => 'web_site',
			 'post_type' => 'custom_fields',
			);
		$post_meta = array(
			'heading_type' => 'Seller Contact Information',
			'classified_heading_type' => 'Seller Contact Information',
			'post_type' => $custom_post_type,
			'post_type_classified' => $custom_post_type,
			'ctype' => 'text',
			'htmlvar_name' => 'web_site',
			'field_category' => 'all',
			'sort_order' => '17',
			'classified_sort_order' => '17',
			'is_submit_field' => '0',
			'is_active' => '1',
			'is_require' => '0',
			'show_on_page' => 'both_side',
			'show_in_column' => '0',
			'show_on_listing' => '1',
			'is_edit' => 'true',
			'is_search' => '0',
			'show_on_detail' => '1',
			'is_delete' => '0',
			'show_in_email'  => '1',
			'field_require_desc' => '',
			'validation_type' => 'require',
			);
		$post_id = wp_insert_post( $my_post );
		wp_set_post_terms( $post_id,'1','category',true );
		if ( is_plugin_active( 'sitepress-multilingual-cms/sitepress.php' ) ) {
			global $sitepress;
			$current_lang_code = ICL_LANGUAGE_CODE;
			$default_language = $sitepress->get_default_language();
			/* Insert wpml  icl_translations table*/
			$sitepress->set_element_language_details( $post_id, $el_type = 'post_custom_fields', $post_id, $current_lang_code, $default_language );
			if ( function_exists( 'wpml_insert_templ_post' ) ) {
				wpml_insert_templ_post( $post_id,'custom_fields' );
			}
		}
		/*wp_set_post_terms($post_id,'1','category',true);*/
		foreach ( $post_meta as $key => $_post_meta ) {
			add_post_meta( $post_id, $key, $_post_meta );
		}
	} else {
		$post_type = get_post_meta( $post_content->ID, 'post_type',true );
		if ( ! strstr( $post_type,'classified' ) ) {
			update_post_meta( $post_content->ID, 'post_type',$post_type . ',classified' );
		}

		update_post_meta( $post_content->ID, 'post_type_classified','classified' );
		update_post_meta( $post_content->ID, 'taxonomy_type_classifiedscategory','classifiedscategory' );


		if ( get_post_meta( $classified_info->ID,'classified_sort_order',true ) ) {
			update_post_meta( $classified_info->ID, 'classified_sort_order',get_post_meta( $classified_info->ID,'classified_sort_order',true ) );
		} else {
			update_post_meta( $classified_info->ID, 'classified_sort_order',17 );
		}
		if ( get_post_meta( $post_content->ID,'heading_type',true ) ) {
			update_post_meta( $post_content->ID, 'classified_heading_type',get_post_meta( $post_content->ID,'heading_type',true ) );
		} else {
			update_post_meta( $post_content->ID, 'classified_heading_type','Label of Field' );
		}
	}// End if().

	/* Insert Consider this classified as into posts */
	$phone = $wpdb->get_row( "SELECT post_title,ID FROM $wpdb->posts WHERE $wpdb->posts.post_name = 'phone' and $wpdb->posts.post_type = 'custom_fields'" );
	if ( count( $phone ) == 0 ) {
		$my_post = array(
			 'post_title' => 'Phone',
			 'post_content' => '',
			 'post_status' => 'publish',
			 'post_author' => 1,
			 'post_name' => 'phone',
			 'post_type' => 'custom_fields',
			);
		$post_meta = array(
			'heading_type' => 'Seller Contact Information',
			'classified_heading_type' => 'Seller Contact Information',
			'post_type' => $custom_post_type,
			'post_type_classified' => $custom_post_type,
			'ctype' => 'text',
			'htmlvar_name' => 'phone',
			'field_category' => 'all',
			'sort_order' => '18',
			'classified_sort_order' => '18',
			'is_submit_field' => '1',
			'is_active' => '1',
			'is_require' => '1',
			'show_on_page' => 'both_side',
			'show_in_column' => '0',
			'show_on_listing' => '1',
			'is_edit' => 'true',
			'is_search' => '1',
			'show_on_detail' => '1',
			'is_delete' => '0',
			'show_in_email'  => '1',
			'field_require_desc' => 'Please enter your valid contact number.',
			'validation_type' => 'phone',
			);
		$post_id = wp_insert_post( $my_post );
		wp_set_post_terms( $post_id,'1','category',true );
		if ( is_plugin_active( 'sitepress-multilingual-cms/sitepress.php' ) ) {
			global $sitepress;
			$current_lang_code = ICL_LANGUAGE_CODE;
			$default_language = $sitepress->get_default_language();
			/* Insert wpml  icl_translations table*/
			$sitepress->set_element_language_details( $post_id, $el_type = 'post_custom_fields', $post_id, $current_lang_code, $default_language );
			if ( function_exists( 'wpml_insert_templ_post' ) ) {
				wpml_insert_templ_post( $post_id,'custom_fields' );
			}
		}
		/*wp_set_post_terms($post_id,'1','category',true);*/
		foreach ( $post_meta as $key => $_post_meta ) {
			add_post_meta( $post_id, $key, $_post_meta );
		}
	} else {
		$post_type = get_post_meta( $phone->ID, 'post_type',true );
		if ( ! strstr( $post_type,'classified' ) ) {
			update_post_meta( $phone->ID, 'post_type',$post_type . ',classified' );
		}

		   update_post_meta( $phone->ID, 'post_type_classified','classified' );
		   update_post_meta( $phone->ID, 'taxonomy_type_classifiedscategory','classifiedscategory' );


		if ( get_post_meta( $phone->ID,'classified_sort_order',true ) ) {
			update_post_meta( $phone->ID, 'classified_sort_order',get_post_meta( $phone->ID,'classified_sort_order',true ) );
		} else {
			update_post_meta( $phone->ID, 'classified_sort_order',18 );
		}
		if ( get_post_meta( $phone->ID,'classified_heading_type',true ) ) {
			update_post_meta( $phone->ID, 'classified_heading_type',get_post_meta( $phone->ID,'classified_heading_type',true ) );
		} else {
			update_post_meta( $phone->ID, 'classified_heading_type','Seller Contact Information' );
		}
	}// End if().


	 /* Insert email field into posts */
	 $post_content = $wpdb->get_row( "SELECT post_title,ID FROM $wpdb->posts WHERE $wpdb->posts.post_name = 'email' and $wpdb->posts.post_type = 'custom_fields'" );
	if ( count( $post_content ) == 0 ) {
		$my_post = array(
		   'post_title' => 'Email',
		   'post_content' => '',
		   'post_status' => 'publish',
		   'post_author' => 1,
		   'post_name' => 'email',
		   'post_type' => 'custom_fields',
		  );
		$post_meta = array(
		  'heading_type' => 'Seller Contact Information',
		  'classified_heading_type' => 'Seller Contact Information',
		  'post_type' => $custom_post_type,
		  'post_type_classified' => $custom_post_type,
		  'ctype' => 'text',
		  'htmlvar_name' => 'email',
		  'field_category' => 'all',
		  'sort_order' => '19',
		  'classified_sort_order' => '19',
		  'is_submit_field' => '1',
		  'is_active' => '1',
		  'is_require' => '1',
		  'show_on_page' => 'both_side',
		  'show_in_column' => '0',
		  'show_on_listing' => '0',
		  'is_edit' => 'true',
		  'show_on_detail' => '1',
		  'is_delete' => '0',
		  'is_search' => '1',
		  'show_in_email'  => '1',
		  'show_on_success' => '0',
		  'field_require_desc' => 'Please enter valid email address.',
		  'validation_type' => 'email',
		  );
		$post_id = wp_insert_post( $my_post );
		wp_set_post_terms( $post_id,'1','category',true );
		if ( is_plugin_active( 'sitepress-multilingual-cms/sitepress.php' ) ) {
			global $sitepress;
			$current_lang_code = ICL_LANGUAGE_CODE;
			$default_language = $sitepress->get_default_language();
			/* Insert wpml  icl_translations table*/
			$sitepress->set_element_language_details( $post_id, $el_type = 'post_custom_fields', $post_id, $current_lang_code, $default_language );
			if ( function_exists( 'wpml_insert_templ_post' ) ) {
				wpml_insert_templ_post( $post_id,'custom_fields' );
			}
		}

		foreach ( $post_meta as $key => $_post_meta ) {
			add_post_meta( $post_id, $key, $_post_meta );
		}
	} else {
		$post_type = get_post_meta( $post_content->ID, 'post_type',true );
		update_post_meta( $post_content->ID, 'is_search','1' );
		if ( ! strstr( $post_type,'classified' ) ) {
			update_post_meta( $post_content->ID, 'post_type',$post_type . ',classified' );
		}

		 update_post_meta( $post_content->ID, 'post_type_classified','classified' );
		 update_post_meta( $post_content->ID, 'taxonomy_type_classifiedscategory','classifiedscategory' );


		if ( get_post_meta( $classified_info->ID,'classified_sort_order',true ) ) {
			update_post_meta( $classified_info->ID, 'classified_sort_order',get_post_meta( $classified_info->ID,'classified_sort_order',true ) );
		} else {
			update_post_meta( $classified_info->ID, 'classified_sort_order',19 );
		}
		if ( get_post_meta( $post_content->ID,'classified_heading_type',true ) ) {
			update_post_meta( $post_content->ID, 'classified_heading_type',get_post_meta( $post_content->ID,'classified_heading_type',true ) );
		} else {
			update_post_meta( $post_content->ID, 'classified_heading_type','Seller Contact Information' );
		}
	}// End if().

	 /* Insert facebook field into posts */
	 $post_content = $wpdb->get_row( "SELECT post_title,ID FROM $wpdb->posts WHERE $wpdb->posts.post_name = 'facebook' and $wpdb->posts.post_type = 'custom_fields'" );
	if ( count( $post_content ) == 0 ) {
		$my_post = array(
		   'post_title' => 'Facebook',
		   'post_content' => '',
		   'post_status' => 'publish',
		   'post_author' => 1,
		   'post_name' => 'facebook',
		   'post_type' => 'custom_fields',
		  );
		$post_meta = array(
		  'heading_type' => 'Seller Contact Information',
		  'classified_heading_type' => 'Seller Contact Information',
		  'post_type' => $post_type_arr,
		  'post_type_classified' => $custom_post_type,
		  'ctype' => 'text',
		  'htmlvar_name' => 'facebook',
		  'field_category' => 'all',
		  'sort_order' => '20',
		  'classified_sort_order' => '20',
		  'is_submit_field' => '0',
		  'is_active' => '1',
		  'is_require' => '0',
		  'show_on_page' => 'both_side',
		  'show_in_column' => '0',
		  'show_on_listing' => '0',
		  'is_edit' => 'true',
		  'show_on_detail' => '1',
		  'is_delete' => '0',
		  'is_search' => '1',
		  'show_in_email'  => '1',
		  'show_on_success' => '0',
		  );
		$post_id = wp_insert_post( $my_post );
		wp_set_post_terms( $post_id,'1','category',true );
		if ( is_plugin_active( 'sitepress-multilingual-cms/sitepress.php' ) ) {
			global $sitepress;
			$current_lang_code = ICL_LANGUAGE_CODE;
			$default_language = $sitepress->get_default_language();
			/* Insert wpml  icl_translations table*/
			$sitepress->set_element_language_details( $post_id, $el_type = 'post_custom_fields', $post_id, $current_lang_code, $default_language );
			if ( function_exists( 'wpml_insert_templ_post' ) ) {
				wpml_insert_templ_post( $post_id,'custom_fields' );
			}
		}

		foreach ( $post_meta as $key => $_post_meta ) {
			add_post_meta( $post_id, $key, $_post_meta );
		}
	} else {
		$post_type = get_post_meta( $post_content->ID, 'post_type',true );
		update_post_meta( $post_content->ID, 'is_search','1' );
		if ( ! strstr( $post_type,'classified' ) ) {
			update_post_meta( $post_content->ID, 'post_type',$post_type . ',classified' );
		}

		update_post_meta( $post_content->ID, 'post_type_classified','classified' );
		update_post_meta( $post_content->ID, 'taxonomy_type_classifiedscategory','classifiedscategory' );


		if ( get_post_meta( $post_content->ID,'classified_sort_order',true ) ) {
			update_post_meta( $post_content->ID, 'classified_sort_order',get_post_meta( $post_content->ID,'classified_sort_order',true ) );
		} else {
			update_post_meta( $post_content->ID, 'classified_sort_order',20 );
		}
		if ( get_post_meta( $post_content->ID,'classified_heading_type',true ) ) {
			update_post_meta( $post_content->ID, 'classified_heading_type',get_post_meta( $post_content->ID,'classified_heading_type',true ) );
		} else {
			update_post_meta( $post_content->ID, 'classified_heading_type','Seller Contact Information' );
		}
	}// End if().

/* Insert linkedin field into posts */
	 $post_content = $wpdb->get_row( "SELECT post_title,ID FROM $wpdb->posts WHERE $wpdb->posts.post_name = 'linkedin' and $wpdb->posts.post_type = 'custom_fields'" );
	if ( count( $post_content ) == 0 ) {
		$my_post = array(
		   'post_title' => 'Linkedin',
		   'post_content' => '',
		   'post_status' => 'publish',
		   'post_author' => 1,
		   'post_name' => 'linkedin',
		   'post_type' => 'custom_fields',
		  );
		$post_meta = array(
		  'heading_type' => 'Seller Contact Information',
		  'classified_heading_type' => 'Seller Contact Information',
		  'post_type' => $post_type_arr,
		  'post_type_classified' => $custom_post_type,
		  'ctype' => 'text',
		  'htmlvar_name' => 'linkedin',
		  'field_category' => 'all',
		  'sort_order' => '20',
		  'classified_sort_order' => '20',
		  'is_submit_field' => '0',
		  'is_active' => '1',
		  'is_require' => '0',
		  'show_on_page' => 'both_side',
		  'show_in_column' => '0',
		  'show_on_listing' => '0',
		  'is_edit' => 'true',
		  'show_on_detail' => '1',
		  'is_delete' => '0',
		  'is_search' => '1',
		  'show_in_email'  => '1',
		  'show_on_success' => '0',
		  );
		$post_id = wp_insert_post( $my_post );
		wp_set_post_terms( $post_id,'1','category',true );
		if ( is_plugin_active( 'sitepress-multilingual-cms/sitepress.php' ) ) {
			global $sitepress;
			$current_lang_code = ICL_LANGUAGE_CODE;
			$default_language = $sitepress->get_default_language();
			/* Insert wpml  icl_translations table*/
			$sitepress->set_element_language_details( $post_id, $el_type = 'post_custom_fields', $post_id, $current_lang_code, $default_language );
			if ( function_exists( 'wpml_insert_templ_post' ) ) {
				wpml_insert_templ_post( $post_id,'custom_fields' );
			}
		}

		foreach ( $post_meta as $key => $_post_meta ) {
			add_post_meta( $post_id, $key, $_post_meta );
		}
	} else {
		$post_type = get_post_meta( $post_content->ID, 'post_type',true );
		update_post_meta( $post_content->ID, 'is_search','1' );
		if ( ! strstr( $post_type,'classified' ) ) {
			update_post_meta( $post_content->ID, 'post_type',$post_type . ',classified' );
		}

		update_post_meta( $post_content->ID, 'post_type_classified','classified' );
		update_post_meta( $post_content->ID, 'taxonomy_type_classifiedscategory','classifiedscategory' );


		if ( get_post_meta( $post_content->ID,'classified_sort_order',true ) ) {
			update_post_meta( $post_content->ID, 'classified_sort_order',get_post_meta( $post_content->ID,'classified_sort_order',true ) );
		} else {
			update_post_meta( $post_content->ID, 'classified_sort_order',20 );
		}
		if ( get_post_meta( $post_content->ID,'classified_heading_type',true ) ) {
			update_post_meta( $post_content->ID, 'classified_heading_type',get_post_meta( $post_content->ID,'classified_heading_type',true ) );
		} else {
			update_post_meta( $post_content->ID, 'classified_heading_type','Seller Contact Information' );
		}
	}// End if().
	/* Insert instagram field into posts */
	 $post_content = $wpdb->get_row( "SELECT post_title,ID FROM $wpdb->posts WHERE $wpdb->posts.post_name = 'instagram' and $wpdb->posts.post_type = 'custom_fields'" );
	if ( count( $post_content ) == 0 ) {
		$my_post = array(
		   'post_title' => 'Instagram',
		   'post_content' => '',
		   'post_status' => 'publish',
		   'post_author' => 1,
		   'post_name' => 'instagram',
		   'post_type' => 'custom_fields',
		  );
		$post_meta = array(
		  'heading_type' => 'Seller Contact Information',
		  'classified_heading_type' => 'Seller Contact Information',
		  'post_type' => $post_type_arr,
		  'post_type_classified' => $custom_post_type,
		  'ctype' => 'text',
		  'htmlvar_name' => 'instagram',
		  'field_category' => 'all',
		  'sort_order' => '20',
		  'classified_sort_order' => '20',
		  'is_submit_field' => '0',
		  'is_active' => '1',
		  'is_require' => '0',
		  'show_on_page' => 'both_side',
		  'show_in_column' => '0',
		  'show_on_listing' => '0',
		  'is_edit' => 'true',
		  'show_on_detail' => '1',
		  'is_delete' => '0',
		  'is_search' => '1',
		  'show_in_email'  => '1',
		  'show_on_success' => '0',
		  );
		$post_id = wp_insert_post( $my_post );
		wp_set_post_terms( $post_id,'1','category',true );
		if ( is_plugin_active( 'sitepress-multilingual-cms/sitepress.php' ) ) {
			global $sitepress;
			$current_lang_code = ICL_LANGUAGE_CODE;
			$default_language = $sitepress->get_default_language();
			/* Insert wpml  icl_translations table*/
			$sitepress->set_element_language_details( $post_id, $el_type = 'post_custom_fields', $post_id, $current_lang_code, $default_language );
			if ( function_exists( 'wpml_insert_templ_post' ) ) {
				wpml_insert_templ_post( $post_id,'custom_fields' );
			}
		}

		foreach ( $post_meta as $key => $_post_meta ) {
			add_post_meta( $post_id, $key, $_post_meta );
		}
	} else {
		$post_type = get_post_meta( $post_content->ID, 'post_type',true );
		update_post_meta( $post_content->ID, 'is_search','1' );
		if ( ! strstr( $post_type,'classified' ) ) {
			update_post_meta( $post_content->ID, 'post_type',$post_type . ',classified' );
		}

		update_post_meta( $post_content->ID, 'post_type_classified','classified' );
		update_post_meta( $post_content->ID, 'taxonomy_type_classifiedscategory','classifiedscategory' );


		if ( get_post_meta( $post_content->ID,'classified_sort_order',true ) ) {
			update_post_meta( $post_content->ID, 'classified_sort_order',get_post_meta( $post_content->ID,'classified_sort_order',true ) );
		} else {
			update_post_meta( $post_content->ID, 'classified_sort_order',20 );
		}
		if ( get_post_meta( $post_content->ID,'classified_heading_type',true ) ) {
			update_post_meta( $post_content->ID, 'classified_heading_type',get_post_meta( $post_content->ID,'classified_heading_type',true ) );
		} else {
			update_post_meta( $post_content->ID, 'classified_heading_type','Seller Contact Information' );
		}
	}// End if().

	 /* Insert twitter field into posts */
	 $post_content = $wpdb->get_row( "SELECT post_title,ID FROM $wpdb->posts WHERE $wpdb->posts.post_name = 'twitter' and $wpdb->posts.post_type = 'custom_fields'" );
	if ( count( $post_content ) == 0 ) {
		$my_post = array(
		   'post_title' => 'Twitter',
		   'post_content' => '',
		   'post_status' => 'publish',
		   'post_author' => 1,
		   'post_name' => 'twitter',
		   'post_type' => 'custom_fields',
		  );
		$post_meta = array(
		  'heading_type' => 'Seller Contact Information',
		  'classified_heading_type' => 'Seller Contact Information',
		  'post_type' => $post_type_arr,
		  'post_type_classified' => $custom_post_type,
		  'ctype' => 'text',
		  'htmlvar_name' => 'twitter',
		  'field_category' => 'all',
		  'sort_order' => '21',
		  'classified_sort_order' => '21',
		  'is_submit_field' => '0',
		  'is_active' => '1',
		  'is_require' => '0',
		  'show_on_page' => 'both_side',
		  'show_in_column' => '0',
		  'show_on_listing' => '0',
		  'is_edit' => 'true',
		  'show_on_detail' => '1',
		  'is_delete' => '0',
		  'is_search' => '1',
		  'show_in_email'  => '1',
		  'show_on_success' => '0',
		  );
		$post_id = wp_insert_post( $my_post );
		wp_set_post_terms( $post_id,'1','category',true );
		if ( is_plugin_active( 'sitepress-multilingual-cms/sitepress.php' ) ) {
			global $sitepress;
			$current_lang_code = ICL_LANGUAGE_CODE;
			$default_language = $sitepress->get_default_language();
			/* Insert wpml  icl_translations table*/
			$sitepress->set_element_language_details( $post_id, $el_type = 'post_custom_fields', $post_id, $current_lang_code, $default_language );
			if ( function_exists( 'wpml_insert_templ_post' ) ) {
				wpml_insert_templ_post( $post_id,'custom_fields' );
			}
		}

		foreach ( $post_meta as $key => $_post_meta ) {
			add_post_meta( $post_id, $key, $_post_meta );
		}
	} else {
		$post_type = get_post_meta( $post_content->ID, 'post_type',true );
		update_post_meta( $post_content->ID, 'is_search','1' );
		if ( ! strstr( $post_type,'classified' ) ) {
			update_post_meta( $post_content->ID, 'post_type',$post_type . ',classified' );
		}

		 update_post_meta( $post_content->ID, 'post_type_classified','classified' );
		 update_post_meta( $post_content->ID, 'taxonomy_type_classifiedscategory','classifiedscategory' );


		if ( get_post_meta( $post_content->ID,'classified_sort_order',true ) ) {
			update_post_meta( $post_content->ID, 'classified_sort_order',get_post_meta( $post_content->ID,'classified_sort_order',true ) );
		} else {
			update_post_meta( $post_content->ID, 'classified_sort_order',21 );
		}
		if ( get_post_meta( $post_content->ID,'classified_heading_type',true ) ) {
			update_post_meta( $post_content->ID, 'classified_heading_type',get_post_meta( $post_content->ID,'classified_heading_type',true ) );
		} else {
			update_post_meta( $post_content->ID, 'classified_heading_type','Seller Contact Information' );
		}
	}// End if().

	 /* Insert google field into posts */
	 $post_content = $wpdb->get_row( "SELECT post_title,ID FROM $wpdb->posts WHERE $wpdb->posts.post_name = 'google' and $wpdb->posts.post_type = 'custom_fields'" );
	if ( count( $post_content ) == 0 ) {
		$my_post = array(
		   'post_title' => 'Google+',
		   'post_content' => '',
		   'post_status' => 'publish',
		   'post_author' => 1,
		   'post_name' => 'google',
		   'post_type' => 'custom_fields',
		  );
		$post_meta = array(
		  'heading_type' => 'Seller Contact Information',
		  'classified_heading_type' => 'Seller Contact Information',
		  'post_type' => $post_type_arr,
		  'post_type_classified' => $custom_post_type,
		  'ctype' => 'text',
		  'htmlvar_name' => 'google',
		  'field_category' => 'all',
		  'sort_order' => '22',
		  'classified_sort_order' => '22',
		  'is_submit_field' => '0',
		  'is_active' => '1',
		  'is_require' => '0',
		  'show_on_page' => 'both_side',
		  'show_in_column' => '0',
		  'show_on_listing' => '0',
		  'is_edit' => 'true',
		  'show_on_detail' => '1',
		  'is_delete' => '0',
		  'is_search' => '1',
		  'show_in_email'  => '1',
		  'show_on_success' => '0',
		  );
		$post_id = wp_insert_post( $my_post );
		wp_set_post_terms( $post_id,'1','category',true );
		if ( is_plugin_active( 'sitepress-multilingual-cms/sitepress.php' ) ) {
			global $sitepress;
			$current_lang_code = ICL_LANGUAGE_CODE;
			$default_language = $sitepress->get_default_language();
			/* Insert wpml  icl_translations table*/
			$sitepress->set_element_language_details( $post_id, $el_type = 'post_custom_fields', $post_id, $current_lang_code, $default_language );
			if ( function_exists( 'wpml_insert_templ_post' ) ) {
				wpml_insert_templ_post( $post_id,'custom_fields' );
			}
		}

		foreach ( $post_meta as $key => $_post_meta ) {
			add_post_meta( $post_id, $key, $_post_meta );
		}
	} else {
		$post_type = get_post_meta( $post_content->ID, 'post_type',true );
		update_post_meta( $post_content->ID, 'is_search','1' );
		if ( ! strstr( $post_type,'classified' ) ) {
			update_post_meta( $post_content->ID, 'post_type',$post_type . ',classified' );
		}

		 update_post_meta( $post_content->ID, 'post_type_classified','classified' );
		 update_post_meta( $post_content->ID, 'taxonomy_type_classifiedscategory','classifiedscategory' );


		if ( get_post_meta( $post_content->ID,'classified_sort_order',true ) ) {
			update_post_meta( $post_content->ID, 'classified_sort_order',get_post_meta( $post_content->ID,'classified_sort_order',true ) );
		} else {
			update_post_meta( $post_content->ID, 'classified_sort_order',22 );
		}
		if ( get_post_meta( $post_content->ID,'classified_heading_type',true ) ) {
			update_post_meta( $post_content->ID, 'classified_heading_type',get_post_meta( $post_content->ID,'classified_heading_type',true ) );
		} else {
			update_post_meta( $post_content->ID, 'classified_heading_type','Seller Contact Information' );
		}
	}// End if().
	 /*Set the Submit classifieds page */
	 $post_content = $wpdb->get_row( "SELECT post_title FROM $wpdb->posts WHERE $wpdb->posts.post_name = 'submit-classified' and $wpdb->posts.post_type = 'page'" );
	if ( count( $post_content ) == 0 ) {
		$my_post = array(
		   'post_title' => 'Submit Classified',
		   'post_content' => "Packages and ad details. [submit_form post_type='classified']",
		   'post_status' => 'publish',
		   'comment_status' => 'closed',
		   'post_author' => 1,
		   'post_name' => 'submit-classified',
		   'post_type' => 'page',
		  );
		$post_meta = array(
		  '_wp_page_template' => 'default',
		  '_edit_last'        => '1',
		  'submit_post_type'  => 'classified',
		  'is_tevolution_submit_form' => 1,
		  );
		$post_id = wp_insert_post( $my_post );
		update_post_meta( $post_id, '_wp_page_template','default' );
		update_post_meta( $post_id, 'submit_post_type','classified' );
		update_post_meta( $post_id, 'is_tevolution_submit_form','1' );
	}

	/*Set the Submit classifieds page */
	$post_content = $wpdb->get_row( "SELECT post_title FROM $wpdb->posts WHERE $wpdb->posts.post_name = 'submit-classified' and $wpdb->posts.post_type = 'page'" );
	if ( count( $post_content ) == 0 ) {
		$my_post = array(
		 'post_title' => 'Submit Classified',
		 'post_content' => "Packages and ad details. [submit_form post_type='classified']",
		 'post_status' => 'publish',
		 'comment_status' => 'closed',
		 'post_author' => 1,
		 'post_name' => 'submit-classified',
		 'post_type' => 'page',
		);
		$post_meta = array(
		'_wp_page_template' => 'default',
		'_edit_last'        => '1',
		'submit_post_type'  => 'classified',
		'is_tevolution_submit_form' => 1,
		);
		$post_id = wp_insert_post( $my_post );
		update_post_meta( $post_id, '_wp_page_template','default' );
		update_post_meta( $post_id, 'submit_post_type','classified' );
		update_post_meta( $post_id, 'is_tevolution_submit_form','1' );


	}
}// End if().
/* Assign classified post type to all existing packages */
if ( is_admin() ) {
	$results = $wpdb->get_results( "SELECT * FROM $wpdb->posts WHERE post_type='monetization_package'" );
	if ( count( $results ) != 0 && ! get_option( 'update_classified_price' ) ) {
		foreach ( $results as $res ) {
			$package_post_type = get_post_meta( $res->ID,'package_post_type',true );
			$package_post_type .= $custom_post_type . ',';
			update_post_meta( $res->ID,'package_post_type',$package_post_type );
		}
		update_option( 'update_classified_price',1 );
	}
}
/*auto install classified sample data*/
function insert_classified_data() {
	global $pagenow,$wpdb;
	if ( $pagenow == 'plugins.php' && ! get_option( 'hide_classified_ajax_notification' ) ) {
		$classified_auto_install = get_option( 'classified_auto_install' );
		$param = 'insert';
		$submit_text = __( 'Install sample data','classifieds' );
		$class = 'button button-primary';
		$msg = __( 'Wish to insert classified sample data?','classifieds' );
		?>
		<strong><?php echo $msg; ?> </strong><span><a href="<?php echo admin_url( 'plugins.php?classified_dummy=' . $param ); ?>" ><?php echo $submit_text; ?></a></span>
		<?php  echo ' <a href="//templatic.com/docs/classifieds-add-on/">' . __( 'Installation Guide','templatic-admin' ) . '</a>';
	}
}
add_filter( 'post_type_key','classified_type_key' );
function classified_type_key( $post_type_key ) {
	if ( $post_type_key === 0 ) {
		$post_type_key = 'classified';
	} else {
		$post_type_key .= ',classified';
	}
	return $post_type_key;
}
?>
