<?php
/* to auto update the plug in */
if ( strstr( $_SERVER['REQUEST_URI'],'plugins.php' ) || strstr( $_SERVER['REQUEST_URI'],'update.php' ) || strstr( $_SERVER['REQUEST_URI'],'update-core.php' ) ) {
	$is_update_page = 0;
	$dateTimestamp1 = get_option( 'tmpl_tvcls_update_check_date' );
	if ( trim( $dateTimestamp1 != '' ) ) {
		$dateTimestamp1 = strtotime( $dateTimestamp1 );
	} else {
		update_option( 'tmpl_tvcls_update_check_date',date( 'Y-m-d H:i:s' ) );
	}
	$dateTimestamp1 = strtotime( get_option( 'tmpl_tvcls_update_check_date' ) );
	$dateTimestamp2 = strtotime( date( 'Y-m-d H:i:s' ) );
	$interval = abs( $dateTimestamp2 - $dateTimestamp1 );
	$hour_diff = intval( round( $interval / 60 ) / 60 );
	/*if ( $hour_diff > 3 || $is_update_page == 1 ) {*/
		require_once( TEVOLUTION_CLASSIFIEDS_DIR . '/wp-updates-plugin.php' );
		new WPClassifiedsUpdates( 'https://templatic.com/_data/updates/api/index.php', plugin_basename( __FILE__ ) );
		if ( $is_update_page == 0 ) {
			update_option( 'tmpl_tvcls_update_check_date',date( 'Y-m-d H:i:s' ) );
		}
	/*} else {
		require_once( TEVOLUTION_CLASSIFIEDS_DIR . '/wp-updates-plugin.php' );
		new WPClassifiedsUpdates( '',plugin_basename( __FILE__ ) );
	}*/
}

/* delete option while deactivate the plugin */
register_deactivation_hook( __FILE__,'tmpl_delete_classifieds_option' );
function tmpl_delete_classifieds_option() {
	delete_option( 'classified_custom_fields_insert' );
}

/* Load style sheet on admin pages */
add_action( 'admin_init', 'tmpl_load_classified_wp_admin_style' );
function tmpl_load_classified_wp_admin_style() {
		wp_register_style( 'tmpl_wp-admin', TEVOLUTION_CLASSIFIEDS_URL . '/css/admin-style.css' );
		wp_enqueue_style( 'tmpl_wp-admin' );
}

/* Add script in admin head section - for browse/upload marker */
add_action( 'admin_init','tmpl_classifieds_add_imgupload_script' );

function tmpl_classifieds_add_imgupload_script() {
	/* script for upload marker in back end */
	wp_enqueue_script( 'function_script',TEVOLUTION_CLASSIFIEDS_URL . 'js/tmpl_admin_upload_image.js',array( 'jquery' ),false );
	wp_enqueue_style( 'thickbox' );
	wp_enqueue_script( 'thickbox' );
}


/***************** Tevolution general settings option *********************/

add_action( 'after_listing_page_sorting','tmpl_custom_fields_classified_tags' );

/* To show the tags of classified status And also to set the position of classified status color settings - close "Before" Hook and create container in "After" Hook */

add_action( 'admin_head','tmpl_add_cls_farbtastic_style_script' );

/* Add colon picker script */
function tmpl_add_cls_farbtastic_style_script() {
	if ( isset( $_REQUEST['page'] ) && $_REQUEST['page'] == 'templatic_settings' ) {
		wp_enqueue_script( 'farbtastic' );
		wp_enqueue_style( 'farbtastic' );
	}
}

/* Add the classified tags settings between general settings -> category page settings  */

function tmpl_custom_fields_classified_tags( $post_id ) {
	global $post;

	?>
	<tr>
		<th><label><?php echo __( 'Set the title and colours for classified status tags','classifieds' ); ?></label></th>
		<td>
			<?php global $wpdb;
			/* get the option where all settings save */
			$tmpdata = get_option( 'templatic_settings' );
			/* Get all the classified status form custom fields */
			$args = array(
				'post_name' => 'classified_tag',
				'post_author' => 1,
				'post_type' => 'custom_fields',
				'meta_query' => array(
					array(
						'key' => 'htmlvar_name',
						'value' => 'classified_tag',
						'compare' => '==',
					),
				),
				'orderby' => 'date',
				'numberposts' => 1,
			);
			/*get field details */
			$classified_tag = new WP_Query( $args );
			foreach ( $classified_tag as $post ) { setup_postdata( $post );
				if ( $post->ID != '' ) {
					$prop_tag_id = $post->ID;
					$prop_tag_value = get_post_meta( $post->ID,'option_values',true );
					$prop_tag_title = get_post_meta( $post->ID,'option_title',true );
				}
			}
			$prop_tags = explode( ',',$prop_tag_value );
			$tag_title = explode( ',',$prop_tag_title );
			echo "<ul class='tmpl_classified-tag-settings'>";
			do_action( 'tmpl_classified_status_settings_start' );
			for ( $t = 0; $t <= count( $prop_tags ); $t++ ) {
				do_action( 'tmpl_classified_status_settings_listart' );
				if ( $tag_title[ $t ] != '' ) {
					$replace = array( ' ','.' );
					$replace_with = array( '','' );
				?>
				<li class="tags-settings"><label> <?php echo $tag_title[ $t ];
				echo ':'; ?></label>
					<div class="element"><input type="text" placeholder="<?php _e( 'Classified tag eg.Hot','classifieds' ); ?>"  name="classified_tag_text_<?php echo str_replace( $replace, $replace_with,$prop_tags[ $t ] ); ?>" value="<?php echo $tmpdata[ 'classified_tag_text_' . str_replace( $replace, $replace_with,$prop_tags[ $t ] ) ]; ?>"/></div>
					<script type="text/javascript">
						jQuery(document).ready(function($){
							jQuery('#classified_tag_color_<?php  echo str_replace( $replace, $replace_with, $prop_tags[ $t ] ); ?>').farbtastic('#cls_color_<?php echo str_replace( $replace, $replace_with, $prop_tags[ $t ] ); ?>');
						});
						/* to show the color picker after click on text box */
						function tmpl_showColorPicker_<?php echo $t; ?>(id,closebtn_id)
						{ 
							document.getElementById(closebtn_id).style.display = '';	
							document.getElementsByName(id)[0].style.display = '';							
						}
					</script>
					<div class="element">
						<?php $cvalue = trim( $tmpdata[ 'classified_tag_color_' . str_replace( $replace, $replace_with, $prop_tags[ $t ] ) ] );

						if ( empty( $cvalue ) || $cvalue == '' || $cvalue == '#' ) { $cvalue = '#b00809'; } ?>
						<input type="text" placeholder="<?php _e( 'Color e.g. #B0DE88','classifieds' ); ?>" value="<?php echo $cvalue; ?>"  name="classified_tag_color_<?php echo str_replace( $replace, $replace_with, $prop_tags[ $t ] ); ?>" id="cls_color_<?php echo str_replace( $replace, $replace_with,$prop_tags[ $t ] ); ?>" onclick="tmpl_showColorPicker_<?php echo $t; ?>(this.id,'classified_tag_close<?php echo str_replace( $replace, $replace_with,$prop_tags[ $t ] ); ?>');"/>
						<!-- close button -->
						<img src="<?php echo TEVOLUTION_CLASSIFIEDS_URL; ?>/images/close.png" class="close_colorpicker_img" onclick="tmpl_clstag_colorpicker_close('classified_tag_color_<?php echo str_replace( $replace, $replace_with, $prop_tags[ $t ] ); ?>',this.id);" id="classified_tag_close<?php echo str_replace( $replace, $replace_with, $prop_tags[ $t ] ); ?>" style="display:none;">
						<div id="classified_tag_color_<?php echo str_replace( $replace, $replace_with,$prop_tags[ $t ] ); ?>"  name="cls_color_<?php echo str_replace( $replace, $replace_with, $prop_tags[ $t ] ); ?>" style="display:none" ></div>
					</div>
					<?php do_action( 'tmpl_classified_status_more_settings_indiv' ); ?>
				</li>
			<?php }
				do_action( 'tmpl_classified_status_settings_liend' );
			}
			do_action( 'tmpl_classified_status_settings_end' );
			do_action( 'tmpl_classified_status_more_colors' );
			echo '</ul>';

			do_action( 'tmpl_classified_status_more_colors' );
			$field_id = $wpdb->get_row( "select ID from $wpdb->posts where post_name ='classified_tag'" );
			echo sprintf( __( 'All the tags you have added in your classified Status custom field are shown here, you can add more tags by %1$s editing that field %2$s.','classifieds' ),'<a href=' . site_url() . '/wp-admin/admin.php?page=custom_setup&ctab=custom_fields&action=addnew&field_id=' . $field_id->ID . '>','</a>' );
			?>
		</td>				 
	</tr>
	<?php
}

/* script to close the color picker after click on close button*/
add_action( 'admin_footer','tmpl_clstag_colorpicker_close_fn' );
function tmpl_clstag_colorpicker_close_fn() {
	?>
	<script type="text/javascript">
	 function tmpl_clstag_colorpicker_close(id,close_id){
		document.getElementById(id).style.display='none';
		document.getElementById(close_id).style.display='none';
	 }
	</script>
<?php
}
/*
	Link of sample classifeids CSV
*/
add_action( 'tevolution_classified_sample_csvfile','tevolution_classified_sample_csvfile' );
function tevolution_classified_sample_csvfile() {
	?>
	 <a href="<?php echo TEVOLUTION_CLASSIFIEDS_URL . 'functions/classifeids_sample.csv';?>"><?php _e( '(Sample csv file)',DIR_DOMAIN );?></a>
		<?php
}

/* With this hook and function we add the sorting options in tevolution general settings section  */
add_action( 'taxonomy_sorting_option','tmpl_classified_taxonomy_sorting_option' );
function tmpl_classified_taxonomy_sorting_option() {
	$tmpdata = get_option( 'templatic_settings' );
	?>
	  <label for="classifieds_price_high_low"><input type="checkbox" id="classifieds_price_high_low" name="sorting_option[]" value="classifieds_price_high_low" <?php if ( ! empty( $tmpdata['sorting_option'] ) && in_array( 'classifieds_price_high_low',$tmpdata['sorting_option'] ) ) { echo 'checked';}?>/>&nbsp;<?php _e( 'Price High to Low (Only for classifieds post type)','classifieds' );?></label><br />
	  <label for="classifieds_price_low_high"><input type="checkbox" id="classifieds_price_low_high" name="sorting_option[]" value="classifieds_price_low_high" <?php if ( ! empty( $tmpdata['sorting_option'] ) && in_array( 'classifieds_price_low_high',$tmpdata['sorting_option'] ) ) { echo 'checked';}?>/>&nbsp;<?php _e( 'Price Low to High (Only for classifieds post type)','classifieds' );?></label><br />
		<?php
}
/* return the default post type as classifieds in manage custom fields section */
add_filter( 'tmpl_default_posttype','tmpl_default_posttype_returns' );
function tmpl_default_posttype_returns() {
	if ( ! is_plugin_active( 'Tevolution-Directory/directory.php' ) ) {
		return CUSTOM_POST_TYPE_CLASSIFIED;
	}
}

/* Listing voucher - templatic plugin compatibility */

if ( get_option( 'listing_vouchers_custom_fields_insert' ) == 'inserted' ) {

	 global $wpdb;
	if ( get_option( 'tmpl_assign_voucher_cls' ) != 'done' ) {
		$post_content = $wpdb->get_row( "SELECT post_name,ID FROM $wpdb->posts WHERE $wpdb->posts.post_name = 'coupons' and $wpdb->posts.post_type = 'custom_fields' and $wpdb->posts.post_status = 'publish'" );
		if ( count( $post_content ) != 0 ) {
			update_post_meta( $post_content->ID, 'classified_heading_type','Label of Field' );
			update_post_meta( $post_content->ID, 'classified_sort_order','18' );
			$post_type = get_post_meta( $post_content->ID, 'post_type',true );
			if ( ! strstr( $post_type,'classified' ) ) {
				update_post_meta( $post_content->ID, 'post_type',$post_type . ',classified' );
			}

				update_post_meta( $post_content->ID, 'post_type_classified','classified' );
				update_post_meta( $post_content->ID, 'taxonomy_type_classifiedscategory','classifiedscategory' );

			update_option( 'tmpl_assign_voucher_cls','done' );
		}
	}
}
/*disable the option to hide on detail page.*/
add_action( 'admin_footer','hide_detail_page_add_id' );
function hide_detail_page_add_id() {
	if ( isset( $_REQUEST['page'] ) && $_REQUEST['page'] == 'custom_setup' && isset( $_REQUEST['field_id'] ) && $_REQUEST['field_id'] != '' ) {
		$field_html_variable_name = get_post_meta( $_REQUEST['field_id'],'htmlvar_name',true );
		if ( $field_html_variable_name == 'ad_id' ) {
			?>
				<script>
					jQuery(window).load(function () {
						jQuery('#show_on_detail').attr("disabled", true);
						jQuery('<input>').attr({
							type: 'hidden',
							name: 'show_on_detail',
							value: 1
						}).appendTo('#show_on_detail');
						jQuery('#show_on_detail').attr("checked", "checked");
					});
				</script>
			<?php
		}
	}
}


/* remove option from related posts settings from backend */
add_filter( 'tmpl_filter_related_post','tmpl_classified_remove_from_related',99 );
function tmpl_classified_remove_from_related( $posttypes ) {
	unset( $posttypes['classified'] );

	return $posttypes;
}
?>
