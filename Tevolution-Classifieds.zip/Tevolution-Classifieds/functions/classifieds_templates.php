<?php
/*
 * Apply filter for custom post type archive page template
 * Function Name: tevolution_get_archive_page_template
 */
function classified_get_archive_page_template( $archive_template ) {

	global $wpdb,$wp_query,$post;
	$custom_post_type = apply_filters( 'directory_post_type_template',tevolution_get_post_type() );
	if ( is_archive() && (get_post_type() == CUSTOM_POST_TYPE_CLASSIFIED || $wp_query->query_vars['post_type'] == CUSTOM_POST_TYPE_CLASSIFIED) ) {

		if ( file_exists( STYLESHEETPATH . '/archive-' . CUSTOM_POST_TYPE_CLASSIFIED . '.php' ) ) {

			$archive_template = STYLESHEETPATH . '/archive-' . CUSTOM_POST_TYPE_CLASSIFIED . '.php';

		} elseif ( file_exists( TEMPLATEPATH . '/archive-' . CUSTOM_POST_TYPE_CLASSIFIED . '.php' ) ) {

			$archive_template = TEMPLATEPATH . '/archive-' . CUSTOM_POST_TYPE_CLASSIFIED . '.php';

		} elseif ( file_exists( TEVOLUTION_CLASSIFIEDS_DIR . 'templates/archive-classified.php' ) ) {

			$archive_template = TEVOLUTION_CLASSIFIEDS_DIR . 'templates/archive-classified.php';
		}
	}
	return $archive_template;
}
add_filter( 'archive_template', 'classified_get_archive_page_template',14 );
/*
 * Apply filter for taxonomy page
 * Function name: get_taxonomy_product_post_type_template
 */
function classified_get_taxonomy_page_template( $taxonomy_template ) {
	global $wpdb,$wp_query,$post;
	/*fetch the current page texonomy*/
	$current_term = $wp_query->get_queried_object();

	if ( $current_term->taxonomy == CUSTOM_CATEGORY_TYPE_CLASSIFIED ) {
		if ( file_exists( STYLESHEETPATH . '/taxonomy-' . $current_term->taxonomy . '.php' ) ) {

			$taxonomy_template = STYLESHEETPATH . '/taxonomy-' . $current_term->taxonomy . '.php';

		} elseif ( file_exists( TEMPLATEPATH . '/taxonomy-' . $current_term->taxonomy . '.php' ) ) {

			$taxonomy_template = TEMPLATEPATH . '/taxonomy-' . $current_term->taxonomy . '.php';

		} else {

			$taxonomy_template = TEVOLUTION_CLASSIFIEDS_DIR . 'templates/taxonomy-classifiedscategory.php';

		}
	}

	 return $taxonomy_template;
}
add_filter( 'taxonomy_template', 'classified_get_taxonomy_page_template',14 );
/*
 * Apply filter for taxonomy page for tags
 * Function name: get_tevolution_tag_page_template
 */
function classified_get_tag_page_template( $tags_template ) {
	global $wpdb,$wp_query,$post;
	/*fetch the current page texonomy*/
	$current_term = $wp_query->get_queried_object();
	if ( $current_term->taxonomy == CUSTOM_TAG_TYPE_CLASSIFIED ) {
		if ( file_exists( STYLESHEETPATH . '/taxonomy-' . $current_term->taxonomy . '.php' ) ) {

			$tags_template = STYLESHEETPATH . '/taxonomy-' . $current_term->taxonomy . '.php';

		} elseif ( file_exists( TEMPLATEPATH . '/taxonomy-' . $current_term->taxonomy . '.php' ) ) {

			$tags_template = TEMPLATEPATH . '/taxonomy-' . $current_term->taxonomy . '.php';

		} else {

			$tags_template = TEVOLUTION_CLASSIFIEDS_DIR . 'templates/taxonomy-classifiedstags.php';

		}
	}
	return $tags_template;

}
add_filter( 'taxonomy_template', 'classified_get_tag_page_template',14 );
/*
 * Apply filter for single template page
 * Function name: get_tevolution_single_template
 */
function classified_get_single_template( $single_template ) {
	global $wpdb,$wp_query,$post;
	if ( get_post_type() == CUSTOM_POST_TYPE_CLASSIFIED ) {
		if ( file_exists( STYLESHEETPATH . '/single-' . get_post_type() . '.php' ) ) {

			$single_template = STYLESHEETPATH . '/single-' . get_post_type() . '.php';

		} elseif ( file_exists( TEMPLATEPATH . '/single-' . get_post_type() . '.php' ) ) {

			$single_template = TEMPLATEPATH . '/single-' . get_post_type() . '.php';

		} else {

			if ( file_exists( TEVOLUTION_CLASSIFIEDS_DIR . 'templates' . $template ) ) {
				$single_template = TEVOLUTION_CLASSIFIEDS_DIR . 'templates/single-classified.php';
			}
		}
	}
	 return $single_template;
}
add_filter( 'single_template', 'classified_get_single_template',14 );
/*
 * Search Page template for only tevolution custom post type
 *
 */

add_filter( 'search_template','classified_get_search_template',14 );
function classified_get_search_template( $search_template ) {
	global $wpdb,$wp_query,$post;
	$post_type = get_query_var( 'post_type' );
	$calendar_classified = get_query_var( 's' );

	/*fetch the tevolution post type*/
	if ( function_exists( 'tevolution_get_post_type' ) ) {
		$custom_post_type = tevolution_get_post_type();
	}
	if ( $post_type == CUSTOM_POST_TYPE_CLASSIFIED  || $wp_query->query_vars['post_type'] == CUSTOM_POST_TYPE_CLASSIFIED ) {
		if ( file_exists( STYLESHEETPATH . '/classified-search.php' ) ) {

			$search_template = STYLESHEETPATH . '/classified-search.php';

		} elseif ( file_exists( TEMPLATEPATH . '/classified-search.php' ) ) {

			$search_template = TEMPLATEPATH . '/classified-search.php';

		} else {
			$search_template = TEVOLUTION_CLASSIFIEDS_DIR . 'templates/classified-search.php';
		}
	}
	 return $search_template;
}

/*  classified preview page filter */
add_action( 'init', 'classified_custom_fields_preview' ,10 );
function classified_custom_fields_preview() {
	if ( isset( $_REQUEST['pid'] ) && $_REQUEST['pid'] != '' ) {
		$_REQUEST['cur_post_type'] = get_post_type( $_REQUEST['pid'] );
	}
	if ( (isset( $_REQUEST['page'] ) && $_REQUEST['page'] == 'preview')  && isset( $_REQUEST['cur_post_type'] ) && $_REQUEST['cur_post_type'] == CUSTOM_POST_TYPE_CLASSIFIED ) {

		if ( file_exists( STYLESHEETPATH . '/single-classified-preview.php' ) ) {

			$single_template_preview = STYLESHEETPATH . '/single-classified-preview.php';

		} elseif ( file_exists( TEMPLATEPATH . '/single-classified-preview.php' ) ) {

			$single_template_preview = TEMPLATEPATH . '/single-classified-preview.php';

		} else {

			$single_template_preview = TEVOLUTION_CLASSIFIEDS_DIR . 'templates/single-classified-preview.php';

		}
		include( $single_template_preview );
		exit;
	}
}

/*Add action get_template_part for product template part */

add_filter( 'directory_post_type_template','tmpl_remove_classified_post_type' );

function tmpl_remove_classified_post_type( $post_type ) {
	if ( !is_author() ) {
		if ( ($key = array_search( 'classified', $post_type )) !== false ) {
			unset( $post_type[ $key ] );
		}
	}
	return $post_type;
}

/* get template for ajax response for list filter. First it will call theme's template. If it is not found, then it will call this pligin's "templates/content-classified.php" and if both not found, then it will call Directory plugin's "templates/content-listing.php" */

add_action( 'tmpl_get_template_classified','tmpl_ajax_classified_template_part' );
if ( ! function_exists( 'tmpl_ajax_classified_template_part' ) ) {
	function tmpl_ajax_classified_template_part( $posttype ) {
		if ( file_exists( STYLESHEETPATH . '/content-' . $posttype . '.php' ) ) {
				$ajax_template = STYLESHEETPATH . '/content-' . $posttype . '.php';
		} else {
			if ( file_exists( TEVOLUTION_CLASSIFIEDS_DIR . 'templates/content-' . $posttype . '.php' ) ) {
				$ajax_template = TEVOLUTION_CLASSIFIEDS_DIR . 'templates/content-' . $posttype . '.php';
			} else { 					$ajax_template = TEVOLUTION_DIRECTORY_DIR . 'templates/content-listing.php';
			}
		}
		echo $ajax_template;
		return include( $ajax_template );
	}
}

