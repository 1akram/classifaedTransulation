<form id="peoperty_searchform" action="<?php echo home_url(); ?>" method="get" role="search">
	 <div>
		  <label class="screen-reader-text" for="s"><?php _e( 'Search for','classifieds' )?>:</label>
		  <input id="s" type="text" name="s" value="">
		  <input type="hidden" name="post_type" value="property" />
		  <input id="searchsubmit" type="submit" value="<?php _e( 'Search','classifieds' );?>">
	 </div>
</form>
