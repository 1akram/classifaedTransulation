<?php
/**
 * Footer Section.
 *
 * @package Wordpress
 * @subpackage Tevolution
 */
	?>
 
</div>
</div>
