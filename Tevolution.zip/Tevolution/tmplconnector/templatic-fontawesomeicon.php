<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action( 'wp_head','get_unicodeicon',11 );

function get_unicodeicon() {
	$all_unicodecss='';
	$cus_post_type = tevolution_get_post_type();
	
	foreach ( $cus_post_type as $post_type ) {	
		global $htmlvar_name;
		if(function_exists('tmpl_get_category_list_customfields')){
			$htmlvar_name = tmpl_get_category_list_customfields($post_type);
		}else{
			global $htmlvar_name;
		}
		foreach ( $htmlvar_name as $key => $val ) {		
			
			$htmlvar_name_arr = $val['htmlvar_name'];
			
			if($htmlvar_name_arr=='post_title')
			{
				if($val['custom_fonticon']!='')
				{
					$unicodeval="'"."\\".$val[custom_fonticon]."'";
					$all_unicodecss .= '.list [class*="post"] .entry-title a:before, .grid [class*="post"] .entry-title a:before{content:'.$unicodeval.'}'."\n";
				}
			}
			if($htmlvar_name_arr=='address')
			{
				if($val['custom_fonticon']!='')
				{
					$unicodeval="'"."\\".$val[custom_fonticon]."'";
					$all_unicodecss .= '.list [class*="post"] p.'.$val["htmlvar_name"].':before, .grid [class*="post"] p.'.$val["htmlvar_name"].':before{content:'.$unicodeval.'}'."\n";
				}
			}
			if($htmlvar_name_arr=='post_excerpt')
			{	
				if($val['custom_fonticon']!='')
				{
					$unicodeval="'"."\\".$val[custom_fonticon]."'";
					$all_unicodecss .= '.list [class*="post"] p.'.$val["htmlvar_name"].':before, .grid [class*="post"] p.'.$val["htmlvar_name"].':before{content:'.$unicodeval.'}'."\n";
				}		
			}
			if($htmlvar_name_arr=='post_content')
			{	
				if($val['custom_fonticon']!='')
				{
					$unicodeval="'"."\\".$val[custom_fonticon]."'";
					$all_unicodecss .= '.list [class*="post"] p.'.$val["htmlvar_name"].':before, .grid [class*="post"] p.'.$val["htmlvar_name"].':before{content:'.$unicodeval.'}'."\n";
				}
			}
			if($htmlvar_name_arr=='listing_timing')
			{	
				if($val['custom_fonticon']!='')
				{
					$unicodeval="'"."\\".$val[custom_fonticon]."'";
					$all_unicodecss .= '.list [class*="post"] p.'.$val["htmlvar_name"].':before, .grid [class*="post"] p.'.$val["htmlvar_name"].':before{content:'.$unicodeval.'}'."\n";
				}
			}
			if($htmlvar_name_arr=='phone')
			{		
				if($val['custom_fonticon']!='')
				{
					$unicodeval="'"."\\".$val[custom_fonticon]."'";
					$all_unicodecss .= '.list [class*="post"] p.'.$val["htmlvar_name"].':before, .grid [class*="post"] p.'.$val["htmlvar_name"].':before{content:'.$unicodeval.'}'."\n";
				}
			}
			if($htmlvar_name_arr=='email')
			{		
				if($val['custom_fonticon']!='')
				{
					$unicodeval="'"."\\".$val[custom_fonticon]."'";
					$all_unicodecss .= '.list [class*="post"] p.'.$val["htmlvar_name"].':before, .grid [class*="post"] p.'.$val["htmlvar_name"].':before{content:'.$unicodeval.'}'."\n";
				}
			}
			if($htmlvar_name_arr=='website')
			{	
				if($val['custom_fonticon']!='')
				{
					$unicodeval="'"."\\".$val[custom_fonticon]."'";
					$all_unicodecss .= '.list [class*="post"] p.'.$val["htmlvar_name"].':before, .grid [class*="post"] p.'.$val["htmlvar_name"].':before{content:'.$unicodeval.'}'."\n";
				}
			}
			if($htmlvar_name_arr=='twitter')
			{	
				if($val['custom_fonticon']!='')
				{
					$unicodeval="'"."\\".$val[custom_fonticon]."'";
					$all_unicodecss .= '.list [class*="post"] p.'.$val["htmlvar_name"].':before, .grid [class*="post"] p.'.$val["htmlvar_name"].':before{content:'.$unicodeval.'}'."\n";
				}
			}
			if($htmlvar_name_arr=='instagram')
			{	
				if($val['custom_fonticon']!='')
				{
					$unicodeval="'"."\\".$val[custom_fonticon]."'";
					$all_unicodecss .= '.list [class*="post"] p.'.$val["htmlvar_name"].':before, .grid [class*="post"] p.'.$val["htmlvar_name"].':before{content:'.$unicodeval.'}'."\n";
				}
			}
			if($htmlvar_name_arr=='linkedin')
			{	
				if($val['custom_fonticon']!='')
				{
					$unicodeval="'"."\\".$val[custom_fonticon]."'";
					$all_unicodecss .= '.list [class*="post"] p.'.$val["htmlvar_name"].':before, .grid [class*="post"] p.'.$val["htmlvar_name"].':before{content:'.$unicodeval.'}'."\n";
				}
			}
			if($htmlvar_name_arr=='youtube')
			{	
				if($val['custom_fonticon']!='')
				{
					$unicodeval="'"."\\".$val[custom_fonticon]."'";
					$all_unicodecss .= '.list [class*="post"] p.'.$val["htmlvar_name"].':before, .grid [class*="post"] p.'.$val["htmlvar_name"].':before{content:'.$unicodeval.'}'."\n";
				}
			}
			if($htmlvar_name_arr=='facebook')
			{		
				if($val['custom_fonticon']!='')
				{
					$unicodeval="'"."\\".$val[custom_fonticon]."'";
					$all_unicodecss .= '.list [class*="post"] p.'.$val["htmlvar_name"].':before, .grid [class*="post"] p.'.$val["htmlvar_name"].':before{content:'.$unicodeval.'}'."\n";
				}
			}
			if($htmlvar_name_arr=='google_plus')
			{	
				if($val['custom_fonticon']!='')
				{
					$unicodeval="'"."\\".$val[custom_fonticon]."'";
					$all_unicodecss .= '.list [class*="post"] p.'.$val["htmlvar_name"].':before, .grid [class*="post"] p.'.$val["htmlvar_name"].':before{content:'.$unicodeval.'}'."\n";
				}
			}
			if($htmlvar_name_arr=='contact_info')
			{	
				if($val['custom_fonticon']!='')
				{
					$unicodeval="'"."\\".$val[custom_fonticon]."'";
					$all_unicodecss .= '.list [class*="post"] p.'.$val["htmlvar_name"].':before, .grid [class*="post"] p.'.$val["htmlvar_name"].':before{content:'.$unicodeval.'}'."\n";
				}
			}
			if ( $htmlvar_name_arr != 'post_title' && $htmlvar_name_arr != 'category' && $htmlvar_name_arr != 'post_content' && $htmlvar_name_arr != 'post_excerpt' && $htmlvar_name_arr != 'post_images' && $htmlvar_name_arr != 'listing_timing' && $htmlvar_name_arr != 'address' && $htmlvar_name_arr != 'listing_logo' && $htmlvar_name_arr != 'video' && $htmlvar_name_arr != 'post_tags' && $htmlvar_name_arr != 'map_view' && $htmlvar_name_arr != 'proprty_feature' && $htmlvar_name_arr != 'phone' && $htmlvar_name_arr != 'email' && $htmlvar_name_arr != 'website' && $htmlvar_name_arr != 'twitter' && $htmlvar_name_arr != 'instagram' && $htmlvar_name_arr != 'linkedin' && $htmlvar_name_arr != 'youtube' && $htmlvar_name_arr != 'facebook' && $htmlvar_name_arr != 'google_plus' && $htmlvar_name_arr != 'contact_info') {
				
				if($val['custom_fonticon']!='')
				{
					$unicodeval="'"."\\".$val[custom_fonticon]."'";
					$all_unicodecss .= '.list [class*="post"] p.'.$val["htmlvar_name"].':before, .grid [class*="post"] p.'.$val["htmlvar_name"].':before{content:'.$unicodeval.'}'."\n";
					$all_unicodecss .= '.list [class*="post"] p.'.$val["htmlvar_name"].' label, .grid [class*="post"] p.'.$val["htmlvar_name"].' label{display:none}'."\n";
					
					$all_unicodecss .= '.tevolution_custom_field p.'.$val["htmlvar_name"].':before{content:'.$unicodeval.'}'."\n";
					$all_unicodecss .= ".tevolution_custom_field p.".$val["htmlvar_name"].":before{font-family:'Font Awesome 5 Pro'; font-weight:600;}"."\n";
					$all_unicodecss .= '.tevolution_custom_field p.'.$val["htmlvar_name"].' label{display:none}'."\n";
					
					$all_unicodecss .= '.entry-header-custom-wrap p.'.$val["htmlvar_name"].':before{content:'.$unicodeval.'}'."\n";		
					$all_unicodecss .= ".entry-header-custom-wrap p.".$val["htmlvar_name"].":before{font-family:'Font Awesome 5 Pro'; font-weight:600;}"."\n";
					$all_unicodecss .= '.entry-header-custom-wrap p.'.$val["htmlvar_name"].' label{display:none !important}'."\n";
					
					$all_unicodecss .= 'p.custom_header_field.'.$val["htmlvar_name"].':before{content:'.$unicodeval.'}'."\n";
					$all_unicodecss .= "p.custom_header_field.".$val["htmlvar_name"].":before{font-family:'Font Awesome 5 Pro'; font-weight:600;}"."\n";
					$all_unicodecss .= 'p.custom_header_field.'.$val["htmlvar_name"].' label{display:none !important}'."\n";
				}
			}			
		}		
	}?>
	<style type="text/css">
	<?php
	echo $all_unicodecss;?>
	</style>
	<?php
}
?>